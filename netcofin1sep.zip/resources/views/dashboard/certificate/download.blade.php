
   <!-- <h1>{!! isset($title) ? $title : '' !!}</h1>
    <h3>{{ isset($subject) ? $subject : '' }}</h3>-->
    <p>{!! isset($content) ? $content: '' !!}</p>
