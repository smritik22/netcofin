@extends('frontEnd.layouts.app')
@section('title','Login')
@section('content')
    <div class="login">
        <div class="row">
            <div class="col-lg-12 login-left">
                <div class="logo">
                    <a href="#"><img src="{{asset('assets/frontend/logo/logo.png') }}" alt="logo"></a>
                    {{-- <h1>Welcome to<br> <strong>DOM</strong></h1> --}}
                    <h1>Coming Soon...<br> <strong>DOM Properties</strong></h1>
                    {{-- <a href="{{route('admin.login')}}">Click me!</a> --}}
                </div>
            </div>
        </div>
    </div>
 @endsection
 