<p>Contact Us:</p>
<p>==============</p>
<p>Email : {{ isset($email) ? $email : '' }}</p>
<p>Name : {{ isset($first_name) ? $first_name : '' }}{{ isset($last_name) ? $last_name : '' }}</p>

<p>Mobile No : {{ isset($mobile_no) ? $mobile_no : '' }}</p>
<p>Message : {{ isset($msg) ? $msg : '-' }}</p>

