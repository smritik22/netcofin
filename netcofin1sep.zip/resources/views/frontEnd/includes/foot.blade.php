@stack('before-scripts')

    <script type="text/javascript" src="{{ asset('assets/frontend/js/jquery.min.js') }}"></script>
    <script type="text/javascript" src="{{ asset('assets/frontend/js/popper.min.js') }}"></script>
    <script type="text/javascript" src="{{ asset('assets/frontend/js/bootstrap.min.js') }}"></script>
    <script type="text/javascript" src="{{ asset('assets/frontend/js/menu.js') }}"></script>
    <script type="text/javascript" src="{{ asset('assets/frontend/js/custom.js') }}"></script>

@stack('after-scripts')
