@extends('frontEnd.layout')
@section('content')

    <!-- Banner -->
    <section class="internal_banner">
    <div class="container">
        <div class="row">
            <div class="col-12">
                <div class="banner_content">
                    <h1>{{ $labels['about_us'] }}</h1>
                </div>
            </div>
        </div>
    </div>
    </section>
    <!-- Banner -->
    <!-- Our Process -->
    <section class="common_padding about_work">
        <div class="container">
            <div class="row">
                <div class="col-md-6">
                    <div class="about_work_img">
                        <img src="{{asset('assets/frontend/images/our_process.jpg')}}" alt="our_process">
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="about_work_content">
                        <h2>{{ $language_id != 1 && @$cms_data->childdata[0]->page_name? $cms_data->childdata[0]->page_name: $cms_data->page_name }}</h2>							
                        <p>{!! $language_id != 1 && @$cms_data->childdata[0]->description ? $cms_data->childdata[0]->description : $cms_data->description !!}
                        </p>
                        <!-- <a href="#" class="common_btn">Explore our process</a> -->
                    </div>
                </div>
            </div>

            <!-- <div class="row about_work_capabilitie">
                <div class="col-md-6 order-md-last">
                    <div class="about_work_img">
                        <img src="images/our_capabilities.jpg" alt="our_capabilities">
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="about_work_content">
                        <h2>Our capabilities</h2>							
                        <p class="comman_p">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
                            tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
                            quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
                            consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
                            cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat.
                        </p>
                        <a href="#" class="common_btn">Explore our capabilities</a>
                    </div>
                </div>
            </div> -->
        </div>
    </section>
    <!-- Our Process -->
@endsection
