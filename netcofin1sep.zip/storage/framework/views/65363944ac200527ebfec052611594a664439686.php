<?php $__env->startSection('title', __('backend.view_subcategory')); ?>
<?php $__env->startPush("after-styles"); ?>
    <link href="<?php echo e(asset("assets/dashboard/js/iconpicker/fontawesome-iconpicker.min.css")); ?>" rel="stylesheet">

    <link rel= "stylesheet" href= "https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.9.0/css/bootstrap-datepicker.min.css" />

<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
<?php
use Illuminate\Support\Carbon;
?>
    <div class="padding edit-package website-label-show">
        <div class="box">
            <div class="box-header dker">
                <h3><?php echo e(__('backend.view_subcategory')); ?>

                </h3>
                <small>
                    <a href="<?php echo e(route('adminHome')); ?>"><?php echo e(__('backend.home')); ?></a> /
                   <a href="<?php echo e(route('generalusers')); ?>"><?php echo e(__('backend.subCategory')); ?></a> /
                   <span><?php echo e(__('backend.view_subcategory')); ?></span>
                </small>
            </div>
            <div class="box-body">
                <?php echo e(Form::open(['route'=>['sub-categories'],'method'=>'GET', 'files' => true,'enctype' => 'multipart/form-data' ])); ?>


                <div class="personal_informations">

                    <div class="form-group row">
                        <label class="col-sm-2 form-control-label"><?php echo __('backend.topicPhoto'); ?> :</label>
                        <?php if($subcategory->image != ''): ?>
                            <div id="user_photo" class="col-sm-4 form-control-label">
                                <a target="_blank" href="<?php echo e($image_url . $subcategory->image); ?>"><img
                                        src="<?php echo e($image_url . $subcategory->image); ?>" >
                                </a>
                            </div>
                        <?php else: ?>
                        <div class="col-sm-4 form-control-label">-</div>
                        <?php endif; ?>

                        <label class="col-sm-2 form-control-label"><?php echo __('backend.category'); ?> :</label>
                        <div class="col-sm-4 form-control-label">
                        <label><?php echo e($subcategory->category->name); ?></label>
                        </div>
                    </div>
                    

                    <div class="form-group row">
                        <label class="col-sm-2 form-control-label"><?php echo __('backend.topicName'); ?> :</label>
                        <div class="col-sm-4 form-control-label">
                           <label><?php echo e(urldecode($subcategory->name)); ?></label>
                        </div>
                    </div>

                    
                    <div class="form-group row">
                    <label class="col-sm-2 form-control-label"><?php echo __('backend.lastUpdated'); ?> :</label>
                        <div class="col-sm-10 form-control-label">
                           <label><?php echo Carbon::parse($subcategory->updated_at)->format(env('DATE_FORMAT','Y-m-d') . ' h:i A'); ?></label>
                        </div>
                    </div>
                </div>
                <div class="form-group row m-t-md">
                    <div class="offset-sm-2">
                        <a href="<?php echo e(route('sub-categories')); ?>" class="btn btn-default m-t" style="margin: 0 0 0 0px">
                            <i class="material-icons">
                            &#xe5cd;</i> <?php echo __('backend.back'); ?>

                        </a>
                    </div>
                </div>
                <?php echo e(Form::close()); ?>

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush("after-scripts"); ?>
    <script src="<?php echo e(asset("assets/dashboard/js/iconpicker/fontawesome-iconpicker.js")); ?>"></script>
    <script src="<?php echo e(asset("assets/dashboard/js/summernote/dist/summernote.js")); ?>"></script>
    <script src= "https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.9.0/js/bootstrap-datepicker.min.js"></script>

 

    <script>

        // update progress bar
        function progressHandlingFunction(e) {
            if (e.lengthComputable) {
                $('progress').attr({value: e.loaded, max: e.total});
                // reset progress on complete
                if (e.loaded == e.total) {
                    $('progress').attr('value', '0.0');
                }
            }
        }
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('dashboard.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/netcofin/public_html/resources/views/dashboard/sub-category/show.blade.php ENDPATH**/ ?>