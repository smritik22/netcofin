<?php $__env->startSection('title', __('backend.category')); ?>
<?php $__env->startSection('content'); ?>
    <link rel="stylesheet" href="https://cdn.datatables.net/1.10.24/css/jquery.dataTables.min.css" type="text/css" />
    <div class="padding website-label">
        <div class="box">

            <div class="box-header dker">
                <h3><?php echo e(__('backend.category')); ?></h3>
                <small>
                    <a href="<?php echo e(route('adminHome')); ?>"><?php echo e(__('backend.home')); ?></a> /
                    <span><?php echo e(__('backend.category')); ?></span>
                </small>
            </div>
            <div class="box-tool">
                <ul class="nav">
                    <li class="nav-item inline">
                        <a class="btn btn-fw primary" href="<?php echo e(route('category.create')); ?>">
                            <i class="material-icons">&#xe7fe;</i>
                            &nbsp; <?php echo e(__('backend.addCategory')); ?>

                        </a>
                    </li>

                </ul>
            </div>
            
            <?php echo e(Form::open(['route' => 'category.updateAll', 'method' => 'post', 'id' => 'updateAll'])); ?>

           
            <div class="bulk-action">
                <select name="action" id="action" class="form-control c-select w-sm inline v-middle" required>
                    <option value="no"><?php echo e(__('backend.bulkAction')); ?></option>
                    <option value="activate"><?php echo e(__('backend.activeSelected')); ?></option>
                    <option value="block"><?php echo e(__('backend.blockSelected')); ?></option>
                    <option value="delete"><?php echo e(__('backend.deleteSelected')); ?></option>
                </select>
                <button type="submit" class="btn white"><?php echo e(__('backend.apply')); ?></button>
            </div>

            <div class="table-responsive">
                <table class="table table-bordered m-a-0" id="program">
                    <thead class="dker">
                    <tr>
                        <th  class="width20 dker no-sort">
                            <label class="ui-check m-a-0">
                                <input id="checkAll" type="checkbox"><i></i>
                            </label>
                        </th>
                        <th><?php echo e(__('backend.topicName')); ?></th>
                        <th><?php echo e(__('backend.image')); ?></th>
                        <th class="text-center" style="width:50px;"><?php echo e(__('backend.status')); ?></th>
                        <th class="text-center" style="width:200px;"><?php echo e(__('backend.options')); ?></th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php if(isset($category_list) && count($category_list) >0): ?>
                        <?php $__currentLoopData = $category_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td class="dker"><label class="ui-check m-a-0">
                                            <input type="checkbox" name="ids[]" value="<?php echo e($type->id); ?>" id="checkforall"><i
                                                class="dark-white"></i>
                                            <?php echo Form::hidden('row_ids[]',$type->id, array('class' => 'form-control row_no')); ?>

                                        </label>
                                    </td>
                                    <td class="h6">
                                        <?php echo isset($type->name) ? urldecode($type->name) : ''; ?> 
                                    </td>
                                    <td class="h6">
                                    <?php if($type->image !=""): ?>
                                        <div>
                                            <img src="<?php echo e(asset('uploads/category/'.$type->image)); ?>"
                                                 style="height: 50px; width:50px;" >
                                        </div>
                                    <?php endif; ?>
                                    </td>
                                    <td class="text-center">
                                        <i class="fa <?php echo e(($type->status != '0') ? 'fa-check text-success':'fa-times text-danger'); ?> inline"></i>
                                    </td>
                                    <td class="text-center">
                                        <a class="btn btn-sm show-eyes list"
                                            href="<?php echo e(route('category.show',['id'=>encrypt($type->id)])); ?>" title="Show">
                                            
                                        </a>

                                        <a class="btn btn-sm success"
                                           href="<?php echo e(route("category.edit",["id"=>encrypt($type->id)])); ?>"
                                           data-toggle="tooltip" data-original-title="<?php echo e(__('backend.edit')); ?>">
                                            <i class="material-icons">&#xe3c9;</i>
                                        </a>
                                    </td>
                                </tr>
                            
                            <!-- .modal -->
                            <div id="m-<?php echo e($type->id); ?>" class="modal fade" data-backdrop="true">
                                <div class="modal-dialog" id="animate">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <h5 class="modal-title"><?php echo e(__('backend.confirmation')); ?></h5>
                                        </div>
                                        <div class="modal-body text-center p-lg">
                                            <p>
                                                <?php echo e(__('backend.confirmationDeleteMsg')); ?>

                                                <br>
                                                <strong>[ <?php echo e(isset($type->name) ? $type->name : ''); ?> ]</strong>
                                            </p>
                                        </div>
                                        <div class="modal-footer">
                                            <button type="button" class="btn dark-white p-x-md"
                                                    data-dismiss="modal"><?php echo e(__('backend.no')); ?></button>
                                            <a href="<?php echo e(route('category.delete',['id'=>$type->id])); ?>"
                                                class="btn danger p-x-md"><?php echo e(__('backend.yes')); ?></a>
                                        </div>
                                    </div><!-- /.modal-content -->
                                </div>
                            </div>
                            <!-- / .modal -->
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                    </tbody>
                </table>
            </div>
            <?php echo e(Form::close()); ?>



            <footer class="dker p-a">
                <div class="row">
                    <div class="col-sm-3 hidden-xs">
                        <!-- .modal -->
                        <div id="m-all" class="modal fade" data-backdrop="true">
                            <div class="modal-dialog" id="animate">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h5 class="modal-title"><?php echo e(__('backend.confirmation')); ?></h5>
                                    </div>
                                    <div class="modal-body text-center p-lg">
                                        <p>
                                            <?php echo e(__('backend.confirmationDeleteMsg')); ?>

                                        </p>
                                    </div>
                                    <div class="modal-footer">
                                        <button type="button" class="btn dark-white p-x-md"
                                            data-dismiss="modal"><?php echo e(__('backend.no')); ?></button>
                                        <button type="submit" class="btn danger p-x-md"><?php echo e(__('backend.yes')); ?></button>
                                    </div>
                                </div><!-- /.modal-content -->
                            </div>
                        </div>
                    </div>
                </div>
            </footer>

            <!-- .modal -->
            <div id="delete_modal" class="modal fade" data-backdrop="true">
                <div class="modal-dialog" id="animate">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title">Confirmation</h5>
                        </div>
                        <div class="modal-body text-center p-lg">
                            <p>
                                <?php echo e(__('backend.confirmationDeleteMsg')); ?>

                                <br>
                                <strong id="show_name"> </strong>
                            </p>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn dark-white p-x-md"
                                data-dismiss="modal"><?php echo e(__('backend.no')); ?></button>
                            <a href="javascript:void(0);"
                                class="btn danger confirmDelete p-x-md"><?php echo e(__('backend.yes')); ?></a>
                        </div>
                    </div><!-- /.modal-content -->
                </div>
            </div>
            <!-- / .modal -->


        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('after-scripts'); ?>
    <script src="https://cdn.datatables.net/1.10.24/js/jquery.dataTables.min.js"></script>
    <script type="text/javascript">
        $( document ).ready(function() {
            if($('.no-sort').hasClass('sorting_disabled')){
                $('.no-sort').removeClass('sorting_asc')
            }
        });
        $('#program').DataTable({
             'columnDefs': [{
                'orderable': false,
                 'targets': [ 0,-1 ]
             }],
        });
     
     
        $("#checkAll").click(function() {
            $('input:checkbox').not(this).prop('checked', this.checked);
        });
        $("#action").change(function() {
            
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('dashboard.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/netcofin/public_html/resources/views/dashboard/category/list.blade.php ENDPATH**/ ?>