<!DOCTYPE html>
<html lang="<?php echo e(@Helper::currentLanguage()->code); ?>" dir="<?php echo e(@Helper::currentLanguage()->direction); ?>">
<head>
    <?php echo $__env->make('frontEnd.includes.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</head>

<body>
    <div id="wrapper">
        <!-- start header -->
        <?php echo $__env->make('frontEnd.includes.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- end header -->
        <div name="location" class="d-none" id="location"></div>
        <input type="hidden" name="cur_latitude" id="cur_latitude">
        <input type="hidden" name="cur_longitude" id="cur_longitude">

        <!-- Content Section -->
        <div class="contents">
            <?php echo $__env->yieldContent('content'); ?>
        </div>
        <!-- end of Content Section -->

        <!-- start footer -->
        <?php echo $__env->make('frontEnd.includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- end footer -->
    </div>
    <?php echo $__env->make('frontEnd.includes.foot', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->yieldContent('footerInclude'); ?>
   
</body>

</html>
<?php /**PATH /var/www/html/netcofin/resources/views/frontEnd/layout.blade.php ENDPATH**/ ?>