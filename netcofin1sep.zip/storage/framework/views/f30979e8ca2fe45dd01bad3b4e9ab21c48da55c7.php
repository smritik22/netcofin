<?php $__env->startSection('title', __('backend.editstate')); ?>
<?php $__env->startPush("after-styles"); ?>
    <link href="<?php echo e(asset("assets/dashboard/js/iconpicker/fontawesome-iconpicker.min.css")); ?>" rel="stylesheet">

    <link rel= "stylesheet" href= "https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.9.0/css/bootstrap-datepicker.min.css" />

    <!--[if lt IE 9]>
    <script src="//html5shim.googlecode.com/svn/trunk/html5.js"></script>
    <![endif]-->

    <style type="text/css">
        .error {
            color: red;
            margin-left: 5px;
        }
    </style>
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
    <div class="padding edit-package">
        <div class="box">
            <div class="box-header dker">
                <h3><i class="material-icons">
                        &#xe02e;</i> <?php echo e(__('backend.editstate')); ?>

                </h3>
                <small>
                    <a href="<?php echo e(route('adminHome')); ?>"><?php echo e(__('backend.home')); ?></a> /
                    <a href="<?php echo e(route('state')); ?>"><?php echo e(__('backend.state')); ?></a> / 
                    <span><?php echo e(__('backend.editstate')); ?></span>

                </small>
            </div>
            <div class="box-tool">
                <ul class="nav">
                    <li class="nav-item inline">
                        <a class="nav-link" href="<?php echo e(route('state')); ?>">
                            <i class="material-icons md-18">×</i>
                        </a>
                    </li>
                </ul>
            </div>
            <div class="box-body">
                <?php echo e(Form::open(['route'=>['state.update',$state->id],'method'=>'POST', 'files' => true,'enctype' => 'multipart/form-data', 'id' => 'stateForm' ])); ?>


                <div class="personal_informations">
                    <div class="form-group row">
                        <label class="col-sm-2 form-control-label"><?php echo __('backend.state_name'); ?></label>
                        <div class="col-sm-10">
                            <input type="text" name="state_name" id="state_name" class="form-control" placeholder="state Name" value="<?php echo e(old('state_name',urldecode($state->name))); ?>" maxlength="100">
                            <span class="help-block">
                                <?php if(!empty(@$errors) && @$errors->has('state_name')): ?>
                                    <span  style="color: red;" class='validate'><?php echo e($errors->first('state_name')); ?></span>
                                <?php endif; ?>
                            </span>
                        </div>
                    </div>

                    <div class="form-group row">
                        <label class="col-sm-2 form-control-label"><?php echo __('backend.country'); ?></label>
                        <div class="col-sm-10">
                            <select name="country" id="country" value="" class="form-control">
                                <option value=>Select country</option>
                                <?php $__currentLoopData = $country_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($value->id); ?>" id="<?php echo e(($state->country_id)); ?>" <?php echo e(($state->country_id == $value->id) ? "selected" : ""); ?>><?php echo e($value->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <span class="help-block">
                                <?php if(!empty(@$errors) && @$errors->has('country')): ?>
                                    <span  style="color: red;" class='validate'><?php echo e($errors->first('country')); ?></span>
                                <?php endif; ?>
                            </span>
                        </div>
                    </div>

                    <div class="form-group row m-t-md">
                        <div class="offset-sm-2 col-sm-10">
                            <button type="submit" class="btn btn-primary m-t" id="submitDetail"><i class="material-icons">&#xe31b;</i> <?php echo __('backend.update'); ?></button>
                            <a href="<?php echo e(route('state')); ?>" class="btn btn-default m-t">
                                <i class="material-icons">
                                &#xe5cd;</i> <?php echo __('backend.cancel'); ?>

                            </a>
                    </div>
                </div>


                <?php echo e(Form::close()); ?>

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush("after-scripts"); ?>
    <script src="<?php echo e(asset('assets/dashboard/js/iconpicker/fontawesome-iconpicker.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/dashboard/js/summernote/dist/summernote.js')); ?>"></script>
    <script src= "https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.9.0/js/bootstrap-datepicker.min.js"></script>


    <script>
        $(function () {
            $('.icp-auto').iconpicker({placement: '<?php echo e((@Helper::currentLanguage()->direction=="rtl")?"topLeft":"topRight"); ?>'});
        });

        // update progress bar
        function progressHandlingFunction(e) {
            if (e.lengthComputable) {
                $('progress').attr({value: e.loaded, max: e.total});
                // reset progress on complete
                if (e.loaded == e.total) {
                    $('progress').attr('value', '0.0');
                }
            }
        }
    </script>
    <script type="text/javascript">
       
        
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('dashboard.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/netcofin/public_html/resources/views/dashboard/state/edit.blade.php ENDPATH**/ ?>