<?php $__env->startSection('title', __('backend.subscription_plans')); ?>
<?php $__env->startSection('content'); ?>
    <link rel="stylesheet" href="https://cdn.datatables.net/1.10.24/css/jquery.dataTables.min.css" type="text/css" />
    <div class="padding website-label">
        <div class="box">

            <div class="box-header dker">
                <h3><?php echo e(__('backend.subscription_plans')); ?></h3>
                <small>
                    <a href="<?php echo e(route('adminHome')); ?>"><?php echo e(__('backend.home')); ?></a> /
                    <span><?php echo e(__('backend.subscription_plans')); ?></span>
                </small>
            </div>

            <div class="box-tool">
                <ul class="nav">
                    <li class="nav-item inline">
                        <a class="btn btn-fw primary" href="<?php echo e(route('subscription_plan.create')); ?>">
                            <i class="material-icons">&#xe7fe;</i>
                            &nbsp; <?php echo e(__('backend.add_subscription_plan')); ?>

                        </a>
                    </li>

                </ul>
            </div>

            <?php echo e(Form::open(['route' => 'subscription_plan.updateAll', 'method' => 'post', 'id' => 'updateAll'])); ?>


                <div class="bulk-action">
                    <select name="action" id="action" class="form-control c-select w-sm inline v-middle" required>
                        <option value="no"><?php echo e(__('backend.bulkAction')); ?></option>
                        <option value="activate"><?php echo e(__('backend.activeSelected')); ?></option>
                        <option value="block"><?php echo e(__('backend.blockSelected')); ?></option>
                        <option value="delete"><?php echo e(__('backend.deleteSelected')); ?></option>
                    </select>
                    <button type="submit" class="btn white"><?php echo e(__('backend.apply')); ?></button>
                </div>


            <div class="table-responsive">
                <table class="table table-bordered m-a-0" id="subscription_plan">
                    <thead class="dker">
                        <tr>
                            <th class="width20 dker">
                                <label class="ui-check m-a-0">
                                    <input id="checkAll" type="checkbox"><i></i>
                                </label>
                            </th>
                            <th><?php echo e(__('backend.subscription_plan_name')); ?></th>
                            <th><?php echo e(__('backend.subscription_plan_duration')); ?></th>
                            <th><?php echo e(__('backend.subscription_plan_price')); ?></th>
                            <th><?php echo e(__('backend.lastUpdated')); ?></th>
                            <th><?php echo e(__('backend.status')); ?></th>
                            <th><?php echo e(__('backend.options')); ?></th>
                        </tr>
                    </thead>
                    <tbody>

                    </tbody>
                </table>
            </div>
            <?php echo e(Form::close()); ?>



            <footer class="dker p-a">
                <div class="row">
                    <div class="col-sm-3 hidden-xs">
                        <!-- .modal -->
                        <div id="m-all" class="modal fade" data-backdrop="true">
                            <div class="modal-dialog" id="animate">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h5 class="modal-title"><?php echo e(__('backend.confirmation')); ?></h5>
                                    </div>
                                    <div class="modal-body text-center p-lg">
                                        <p>
                                            <?php echo e(__('backend.confirmationDeleteMsg')); ?>

                                        </p>
                                    </div>
                                    <div class="modal-footer">
                                        <button type="button" class="btn dark-white p-x-md"
                                            data-dismiss="modal"><?php echo e(__('backend.no')); ?></button>
                                        <button type="submit" class="btn danger p-x-md"><?php echo e(__('backend.yes')); ?></button>
                                    </div>
                                </div><!-- /.modal-content -->
                            </div>
                        </div>
                    </div>
                </div>
            </footer>

            <!-- .modal -->
            <div id="delete_modal" class="modal fade" data-backdrop="true">
                <div class="modal-dialog" id="animate">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title">Confirmation</h5>
                        </div>
                        <div class="modal-body text-center p-lg">
                            <p>
                                <?php echo e(__('backend.confirmationDeleteMsg')); ?>

                                <br>
                                <strong id="show_name"> </strong>
                            </p>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn dark-white p-x-md"
                                data-dismiss="modal"><?php echo e(__('backend.no')); ?></button>
                            <a href="javascript:void(0);"
                                class="btn danger confirmDelete p-x-md"><?php echo e(__('backend.yes')); ?></a>
                        </div>
                    </div><!-- /.modal-content -->
                </div>
            </div>
            <!-- / .modal -->


        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('after-scripts'); ?>
    <script src="https://cdn.datatables.net/1.10.24/js/jquery.dataTables.min.js"></script>
    <script type="text/javascript">

        function deleteData(element) {
            let user_name = $(element).data('name');
            let href = $(element).data('href');

            $('#show_name').text(user_name);
            $('.confirmDelete').attr('href', href);
            $("#delete_modal").modal('show')
        }

        $(function() {
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });
            load_data();

            function load_data() {
                var action_url = "<?php echo route('subscription_plan.anyData'); ?> ";
                $('#subscription_plan').DataTable({
                    processing: true,
                    serverSide: true,
                    responsive: true,
                    ordering: true,
                    columnDefs: [{
                        'bSortable': false,
                        'aTargets': [0, 6]
                    }],
                    ajax: {
                        url: action_url,
                        type: 'POST',
                        data: {

                        }
                    },
                    columns: [{
                            data: 'checkbox',
                            name: 'checkbox',
                            orderable: false,
                            searchable: false
                        },
                        {
                            data: 'plan_name',
                            name: 'plan_name',

                        },
                        {
                            data: 'plan_duration',
                            name: 'plan_duration',

                        },
                        {
                            data: 'plan_price',
                            name: 'plan_price',

                        },
                        {
                            data: 'updated_at',
                            name: 'updated_at',

                        },
                        {
                            data: 'status',
                            name: 'status',
                            orderable: false,
                            searchable: false,
                        },
                        {
                            data: 'options',
                            orderable: false,
                            searchable: false
                        }
                    ],
                    order: ['0', 'DESC']
                });
            }

        });
        $("#checkAll").click(function() {
            $('input:checkbox').not(this).prop('checked', this.checked);
        });
        $("#action").change(function() {
            
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('dashboard.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/netcofin/public_html/resources/views/dashboard/subscription_plans/list.blade.php ENDPATH**/ ?>