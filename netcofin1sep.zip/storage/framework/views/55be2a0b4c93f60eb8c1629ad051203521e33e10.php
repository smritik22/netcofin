    <meta charset="UTF-8">
    <title><?php echo e($labels['site_title']); ?></title>

    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="keywords" content="<?php echo e($PageKeywords); ?>" />
    <meta name="author" content="<?php echo e(URL::to('')); ?>" />

    <meta name="description" content="<?php echo e($PageDescription); ?>"/>
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, minimal-ui"/>
    <meta http-equiv="X-UA-Compatible" content="IE=edge">

    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-status-barstyle" content="black-translucent">
    <link rel="apple-touch-icon" href="<?php echo e(asset('assets/frontend/logo/Logo_White.jpg')); ?>">
    <meta name="apple-mobile-web-app-title" content="Smartend">
    
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <meta name="mobile-web-app-capable" content="yes">
    
    <!-- Main Style -->
    <link href="https://fonts.googleapis.com/css2?family=Karla:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo e(asset('assets/frontend/css/bootstrap.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/frontend/css/style.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/frontend/css/responsive.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/frontend/css/menu.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/frontend/css/owl.carousel.css')); ?>">
    
    <!-- <link rel="icon" href="<?php echo e(asset('assets/img/favicon.png')); ?>" type="image/gif">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Manrope:wght@400;500;600;700;800&display=swap"
        rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/frontend/css/bootstrap.min.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/frontend/css/ui-slider.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/frontend/css/menu.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/frontend/css/style.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/frontend/css/arabic.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/frontend/css/responsive.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/frontend/css/custom.css')); ?>"> -->

    <!-- Favicon and Touch Icons -->
    <?php if(Helper::GeneralSiteSettings('style_fav') != ''): ?>
        <link href="<?php echo e(URL::asset('uploads/settings/' . Helper::GeneralSiteSettings('style_fav'))); ?>"
            rel="shortcut icon" type="image/png">
    <?php else: ?>
        <link href="<?php echo e(URL::asset('/assets/frontend/images/favicon.png')); ?>" rel="shortcut icon" type="image/png">
    <?php endif; ?>

    <meta property='og:title'
        content='<?php echo e($PageTitle); ?> <?php echo e($PageTitle == '' ? Helper::GeneralSiteSettings('site_title_' . trans('backLang.boxCode')) : ''); ?>' />
    <?php if(@$Topic->photo_file != ''): ?>
        <meta property='og:image' content='<?php echo e(URL::asset('uploads/topics/' . @$Topic->photo_file)); ?>' />
    <?php elseif(Helper::GeneralSiteSettings('style_apple') != ''): ?>
        <meta property='og:image'
            content='<?php echo e(URL::asset('uploads/settings/' . Helper::GeneralSiteSettings('style_apple'))); ?>' />
    <?php else: ?>
        <!-- <meta property='og:image' content='<?php echo e(URL::asset('uploads/settings/nofav.png')); ?>' /> -->
    <?php endif; ?>
    <meta property="og:site_name"
        content="<?php echo e(Helper::GeneralSiteSettings('site_title_' . trans('backLang.boxCode'))); ?>">
    <meta property="og:description" content="<?php echo e($PageDescription); ?>" />
    <meta property="og:url" content="<?php echo e(url()->full()); ?>" />
    <meta property="og:type" content="website" />
    
    
    
<?php /**PATH /home/netcofin/public_html/resources/views/frontEnd/includes/head.blade.php ENDPATH**/ ?>