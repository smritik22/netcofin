<?php $__env->startSection('title', __('backend.emailtemplate')); ?>
<?php $__env->startSection('content'); ?>
    
    <link rel="stylesheet" href="https://cdn.datatables.net/1.10.24/css/jquery.dataTables.min.css" type="text/css" />  
    <div class="padding">
        <div class="box">

            <div class="box-header dker">
                <h3><?php echo e(__('backend.emailtemplate')); ?></h3>
                <small>
                    <a href="<?php echo e(route('adminHome')); ?>"><?php echo e(__('backend.home')); ?></a> /
                    <span><?php echo e(__('backend.emailtemplate')); ?></span>
                </small>
            </div>

            <div class="box-tool">
                <ul class="nav">
                            <li class="nav-item inline">
                                <a class="btn btn-fw primary" href="<?php echo e(route('emailtemplate.create')); ?>">
                                    <i class="material-icons">&#xe02e;</i>
                                    &nbsp; New Email Templete
                                </a>
                            </li>
                </ul>
            </div>

                

            <?php if($emailtemplate == 0): ?>
                <div class="row p-a">
                    <div class="col-sm-12">
                        <div class=" p-a text-center ">
                            <?php echo e(__('backend.noData')); ?>

                            <br>
                            <?php if(@Auth::user()->permissionsGroup->webmaster_status): ?>
                                <br>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            <?php endif; ?>

            <?php if($emailtemplate > 0): ?>
            <?php echo e(Form::open(['route' => 'emailtemplate.updateAll', 'method' => 'post', 'id' => 'updateAll'])); ?>


                <div class="bulk-action">
                    <select name="action" id="action" class="form-control c-select w-sm inline v-middle" required>
                        <option value="no"><?php echo e(__('backend.bulkAction')); ?></option>
                        <option value="activate"><?php echo e(__('backend.activeSelected')); ?></option>
                        <option value="block"><?php echo e(__('backend.blockSelected')); ?></option>
                        <option value="delete"><?php echo e(__('backend.deleteSelected')); ?></option>
                    </select>
                    <button type="submit" class="btn white"><?php echo e(__('backend.apply')); ?></button>
                </div>
                <div class="table-responsive">
                    <table class="table table-bordered m-a-0" id="emailtemplate">
                        <thead class="dker">
                        <tr>
                            <th>id</th>
                            <th class="width20 dker">
                                <label class="ui-check m-a-0">
                                    <input id="checkAll" type="checkbox"><i></i>
                                </label>
                            </th>
                            <th><?php echo e(__('backend.topicName')); ?></th>
                            <th><?php echo e(__('backend.subject')); ?></th>
                            <th><?php echo e(__('backend.options')); ?></th>
                        </tr>
                        </thead>
                        <tbody id="emailTemplateTable">

                        </tbody>
                    </table>

                </div>
               
                <?php echo e(Form::close()); ?>

            <?php endif; ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush("after-scripts"); ?>
 <script src="https://cdn.datatables.net/1.10.24/js/jquery.dataTables.min.js"></script>
    <script type="text/javascript">
        $(function() {
           $.ajaxSetup({
               headers: {
                   'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
               }
           });
           load_data();
           function load_data() 
           {
        
              var action_url = "<?php echo route('emailtemplate.anyData'); ?> ";
            
               $('#emailtemplate').DataTable({
                   processing: true,
                   serverSide: true,
                   responsive: true,
                   ordering: true,
                   columnDefs: [{
                       'bSortable': false,
                       'aTargets': [0,4]
                   }],
                   ajax: {
                       url : action_url,
                       type: 'POST',
                       data:{
                       
                       }
                   },
                   columns: [
                   {
                       data: 'id',
                       name: 'id',
                       visible:false
                     
                   },
                   {
                            data: 'checkbox',
                            name: 'checkbox',
                            orderable: false,
                            searchable: false
                    },
                   {
                       data: 'title',
                       name: 'title',
                     
                   },
                   {
                      data: 'subject',
                      name: 'subject',
                   },
                  
                   {
                       data: 'options',
                       orderable: false,
                       searchable: false
                   }
                   ],
                   order: ['0', 'DESC']
               });
           }
        
        });
    
        $("#checkAll").click(function () {
            $('input:checkbox').not(this).prop('checked', this.checked);
        });
        $("#action").change(function () {
            if (this.value == "delete") {
                $("#submit_all").css("display", "none");
                $("#submit_show_msg").css("display", "inline-block");
            } else {
                $("#submit_all").css("display", "inline-block");
                $("#submit_show_msg").css("display", "none");
            }
        });


        $("#filter_btn").click(function () {
            $("#filter_div").slideToggle();
        });

        $("#find_q").on("keyup", function() {
            var value = $(this).val().toLowerCase();
            $("#doctorTypeTable tr").filter(function() {
                $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
            });
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('dashboard.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/netcofin/public_html/resources/views/dashboard/emailtemplate/list.blade.php ENDPATH**/ ?>