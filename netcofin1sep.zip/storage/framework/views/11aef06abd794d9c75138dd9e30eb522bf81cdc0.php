<?php
use App\Helpers;

 $content = Helper::getEmailtemplateContentForgotpassword($id,$email,$password,$name,$url,$logo);
?>
<div><?php echo $content; ?></div>

<?php /**PATH /home/netcofin/public_html/resources/views/password.blade.php ENDPATH**/ ?>