<?php echo $__env->yieldPushContent('before-scripts'); ?>

    <script type="text/javascript" src="<?php echo e(asset('assets/frontend/js/jquery.min.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('assets/frontend/js/popper.min.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('assets/frontend/js/bootstrap.min.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('assets/frontend/js/menu.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('assets/frontend/js/custom.js')); ?>"></script>

<?php echo $__env->yieldPushContent('after-scripts'); ?>
<?php /**PATH /var/www/html/netcofin/resources/views/frontEnd/includes/foot.blade.php ENDPATH**/ ?>