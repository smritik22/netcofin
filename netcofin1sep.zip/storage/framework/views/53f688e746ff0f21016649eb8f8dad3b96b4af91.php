<?php $__env->startSection('title','Edit Profile'); ?>
<?php $__env->startSection('content'); ?>
    <div class="padding edit-package edit-user">
        <div class="box">
            <div class="box-header dker">
                <h3><i class="material-icons">&#xe3c9;</i> Edit Profile</h3>
                <small>
                    <a href="<?php echo e(route('adminHome')); ?>"><?php echo e(__('backend.home')); ?></a> /
                    <span>Edit Profile</span>
                </small>
            </div>
            <div class="box-tool">
                <ul class="nav">
                    <li class="nav-item inline">
                        <a class="nav-link" href="<?php echo e(route("users")); ?>">
                            <i class="material-icons md-18">×</i>
                        </a>
                    </li>
                </ul>
            </div>
            <div class="box-body">
                <?php echo e(Form::open(['route'=>['usersUpdate',$Users->id],'method'=>'POST', 'files' => true])); ?>


                <div class="form-group row">
                    <label for="name"
                           class="col-sm-2 form-control-label"><?php echo __('backend.fullName'); ?>

                    </label>
                    <div class="col-sm-10">
                        <?php echo Form::text('name',$Users->name, array('placeholder' => '','class' => 'form-control','id'=>'name','required'=>'')); ?>

                    </div>
                </div>

                <div class="form-group row">
                    <label for="email"
                           class="col-sm-2 form-control-label"><?php echo __('backend.loginEmail'); ?>

                    </label>
                    <div class="col-sm-10">
                        <?php echo Form::email('email',$Users->email, array('placeholder' => '','class' => 'form-control','id'=>'email','required'=>'')); ?>

                    </div>
                </div>

                

                <div class="form-group row">
                    <label for="photo_file"
                           class="col-sm-2 form-control-label"><?php echo __('backend.topicPhoto'); ?></label>
                    <div class="col-sm-10">
                        <?php if($Users->profile_photo!=""): ?>
                            <div class="row">
                                <div class="col-sm-12 images">
                                    <div id="user_photo" class="col-sm-4 box p-a-xs">
                                        <a target="_blank"
                                           href="<?php echo e(asset('uploads/contacts/'.$Users->profile_photo)); ?>"><img
                                                src="<?php echo e(asset('uploads/contacts/'.$Users->profile_photo)); ?>"
                                                class="img-responsive">
                                        </a>
                                        <br>
                                        <div class="delete">
                                            <a onclick="document.getElementById('user_photo').style.display='none';document.getElementById('photo_delete').value='1';document.getElementById('undo').style.display='block';"
                                            class="btn btn-sm btn-default"><?php echo __('backend.delete'); ?></a>
                                            <?php echo e($Users->profile_photo); ?>

                                        </div>
                                    </div>
                                    <div id="undo" class="col-sm-4 p-a-xs" style="display: none">
                                        <a onclick="document.getElementById('user_photo').style.display='block';document.getElementById('photo_delete').value='0';document.getElementById('undo').style.display='none';">
                                            <i class="material-icons">&#xe166;</i> <?php echo __('backend.undoDelete'); ?>

                                        </a>
                                    </div>

                                    <?php echo Form::hidden('photo_delete','0', array('id'=>'photo_delete')); ?>

                                </div>
                            </div>
                        <?php endif; ?>

                        <?php echo Form::file('photo', array('class' => 'form-control','id'=>'photo','accept'=>'image/*')); ?>

                        <small>
                            <i class="material-icons">&#xe8fd;</i>
                            <?php echo __('backend.imagesTypes'); ?>

                        </small>
                    </div>
                </div>

                


                <div class="form-group row m-t-md">
                    <div class="offset-sm-2 col-sm-10">
                        <button type="submit" class="btn btn-primary m-t"><i class="material-icons">
                                &#xe31b;</i> <?php echo __('backend.update'); ?></button>
                        <a href="<?php echo e(route('adminHome')); ?>"
                           class="btn btn-default m-t"><i class="material-icons">
                                &#xe5cd;</i> <?php echo __('backend.cancel'); ?></a>
                    </div>
                </div>

                <?php echo e(Form::close()); ?>

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/netcofin/public_html/resources/views/dashboard/users/edit.blade.php ENDPATH**/ ?>