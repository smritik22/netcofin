<?php $__env->startSection('content'); ?>
    <!-- Banner -->
    <section class="internal_banner">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="banner_content">
                        <h1><?php echo e($labels['subscription_plan']); ?></h1>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- Banner -->
    <!-- Choose Your Plan -->
    <section class="common_padding choose_plan">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="section_title">
                        <h2>Choose your plan</h2>
                        <h4>I'm a paragraph. I’m a great place for you to tell a story and let your users know a little more about you.</h4>
                    </div>
                </div>
            </div>
            
            <div class="row plan_row">
                <?php $__currentLoopData = $subscription_plans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-md-4 col-sm-6">
                        <div class="plan_box">
                            <h3><?php echo $language_id != 1 && @$value->childdata[0]->plan_name ? $value->childdata[0]->plan_name : $value->plan_name; ?> </h3>
                            <?php
                                    $duration = \Helper::getValidTillDate(date('Y-m-d H:i:s'),$value->plan_duration_value, $value->plan_duration_type);
                            ?>
                            <div class="plan_type">

                                <?php if(!$value->is_free_plan && $value->plan_price != '0.00'): ?>
                                <h3><?php echo e(\Helper::getDefaultCurrency().$value->plan_price); ?><span>/<?php echo e(($duration['value'] == 1) ? 'Monthly' : $duration['value'] . ' ' . $duration['label_value']); ?></span></h3>
                                <?php else: ?>
                                <h3>Free</h3>
                                <?php endif; ?>
                            </div>
                            <p><?php echo $language_id != 1 && @$value->childdata[0]->plan_description ? $value->childdata[0]->plan_description : $value->plan_description; ?></p>
                           
                            <div class="bottom_btn">
                                <a class="common_btn transparent" onClick="reply_click(this.id)" id="<?php echo e($value->id); ?>">CHOOSE PLAN</a>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                
            </div>

            <div class="row">
                <div class="col-12">
                    <div class="bottom_btn view_all">
                        <a class="common_btn" id="pay_now"><?php echo e($labels['pay_now']); ?> </a>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('after-scripts'); ?>
    <script>
        function reply_click(clicked_id)
        {
            alert(clicked_id);
            var url = '<?php echo e(route("frontend.register", ":id")); ?>';
            url = url.replace(':id', clicked_id);
            $('#pay_now').attr("href",url);
        }
        function popup(mylink, windowname) {
            winopened = window.open(mylink, windowname); 
            winopened.onblur = () => winopened.focus();
            
        } 

        function resultFetched(response) {
            winopened.close();
            console.info(response);

            if(response.Result == "<?php echo e(config('constants.UPAY_RESULT.success')); ?>") {
                $('#PaymentID').val(response.PaymentID);
                $('#TrackID').val(response.TranID);
                
                $('#trnUdf').val(response.trnUdf);
                $('#Auth').val(response.Auth);
            } else {
                Swal.fire({
                    icon: 'error',
                    iconColor : '#bb4f4f',
                    text: "<?php echo e($labels['payment_failed']); ?>",
                    showConfirmButton: true,
                    confirmButtonText: "<?php echo e($labels['ok']); ?>",
                });
            }
            // alert('Yes this is called now');
        }

        $().ready(function () {
            // $("#pay_now").click( function(e) {
            //     let subscription_plan = $('input[name="subscription_plan"]:checked').data('price');
            //     var is_renew = $("#is_renew").val();
                
            //     let is_loggedin = "<?php echo e((@Auth::guard('web')->check()) ? 1 : 0); ?>";
                
            //     if(is_loggedin == "1") {
                    
            //         // if(is_renew == 1) {
            //         //     total_amount = ("#renew_plan_submit").data('price');
            //         // } 
            //         // else if( is_renew == 2) {
            //             if( typeof(subscription_plan) != "undefined" && subscription_plan !== null ) {
            //                 $("#subscription_plan_error").text("");
            //                 total_amount = subscription_plan;
            //             } else {
            //                 $("#subscription_plan_error").text("<?php echo e($labels['please_select_plan']); ?>");
            //                 return false;
            //             }
            //         // }
    
            //         $.ajax({
            //             url : "<?php echo e(route('frontend.payment')); ?>",
            //             data : {"user_id" : "<?php echo e(Auth::guard('web')->id()); ?>", "payable_amount" : total_amount, "language_id" : "<?php echo e($language_id); ?>", "is_web":1},
            //             type : 'post',
            //             dataType : 'json',
            //             success : function (response) {
            //                 if(response[0].code == 1) {
            //                     popup(response[0].redirect_url, '_blank');
            //                 } else {
            //                     Swal.fire({
            //                         icon: 'error',
            //                         iconColor : '#bb4f4f',
            //                         text: "<?php echo e($labels['something_went_wrong']); ?>",
            //                         showConfirmButton: true,
            //                         confirmButtonText: "<?php echo e($labels['ok']); ?>",
            //                     }).then(function (res) {
            //                         location.reload();
            //                     });
            //                     return false;
            //                 }
    
            //                 loader_hide();
            //             },
            //             error : function (err) {
            //                 loader_hide();
            //                 Swal.fire({
            //                     icon: 'error',
            //                     iconColor : '#bb4f4f',
            //                     text: "<?php echo e($labels['something_went_wrong']); ?>",
            //                     showConfirmButton: true,
            //                     confirmButtonText: "<?php echo e($labels['ok']); ?>",
            //                 }).then(function (res) {
            //                     location.reload();
            //                 });
            //                 return false;
            //             }
            //         });
            //     } else {
            //         Swal.fire({
            //             title: "<?php echo e($labels['login_required']); ?>",
            //             showDenyButton: true,
            //             showConfirmButton: true,
            //             confirmButtonText: "<?php echo e($labels['go_to_login']); ?>",
            //             denyButtonText: `<?php echo e($labels['cancle']); ?>`,
            //             confirmButtonColor: "#2A4B9B",
            //             heightAuto: false,
            //         }).then((result) => {
            //             if (result.isConfirmed) {
            //                 window.location.href = "<?php echo e(route('frontend.login')); ?>";
            //             }
            //         });
            //     }
            // });
        });
    </script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('frontEnd.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/netcofin/public_html/resources/views/frontEnd/subscription/subscription_plans_list.blade.php ENDPATH**/ ?>