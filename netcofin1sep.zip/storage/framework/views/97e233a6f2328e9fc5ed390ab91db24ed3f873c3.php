<div class="app-header white box-shadow navbar-md">
    <div class="navbar">
        <!-- Open side - Naviation on mobile -->
        <a data-toggle="modal" data-target="#aside" class="navbar-item pull-left hidden-lg-up">
            <i class="material-icons">&#xe5d2;</i>
        </a>
        <!-- / -->

        <!-- Page title - Bind to $state title -->
        <div class="navbar-item pull-left h5" ng-bind="$state.current.data.title" id="pageTitle"></div>

        <!-- navbar right -->
        <ul class="nav navbar-nav pull-right">
            
            
            <li class="nav-item dropdown">
                <a class="nav-link clear" href data-toggle="dropdown">
                    <span class="avatar">
                        <?php if(Auth::user()->profile_photo != ''): ?>
                            <img src="<?php echo e(asset('uploads/contacts/' . Auth::user()->profile_photo)); ?>"
                                alt="<?php echo e(Auth::user()->name); ?>" title="<?php echo e(Auth::user()->name); ?>">
                        <?php else: ?>
                            <img src="<?php echo e(asset('uploads/contacts/profile.png')); ?>" alt="<?php echo e(Auth::user()->name); ?>"
                                title="<?php echo e(Auth::user()->name); ?>">
                        <?php endif; ?>
                        <i class="on b-white bottom"></i>
                    </span>
                </a>
                <div class="dropdown-menu pull-right dropdown-menu-scale">
                    <?php if(@Helper::GeneralWebmasterSettings('inbox_status')): ?>
                        <?php if(@Auth::user()->permissionsGroup->inbox_status): ?>
                            
                        <?php endif; ?>
                    <?php endif; ?>

                    <a class="dropdown-item"
                        href="<?php echo e(route('usersEdit', Auth::user()->id)); ?>"><span><?php echo e(__('backend.profile')); ?></span></a>
                    <div class="dropdown-divider"></div>
                    <a class="dropdown-item" href="<?php echo e(route('admin-change-password')); ?>"><span>Change
                            Password</span></a>
                    <div class="dropdown-divider"></div>
                    <a onclick="event.preventDefault();document.getElementById('logout-form').submit();"
                        class="dropdown-item" href="<?php echo e(url('/logout')); ?>">Logout</a>

                    <form id="logout-form" action="<?php echo e(route('main-user-logout')); ?>" method="POST"
                        style="display: none;">
                        <?php echo e(csrf_field()); ?>

                    </form>
                </div>
            </li>

            <li class="nav-item hidden-md-up">
                <a class="nav-link" data-toggle="collapse" data-target="#collapse">
                    <i class="material-icons">&#xe5d4;</i>
                </a>
            </li>
            <li class="header-switcher show-switcher-icon">
                <a href ui-toggle-class="active" target="#sw-theme"
                    class="box-color dark-white text-color sw-btn hidden-switcher-icon">
                    <i class="fa fa-gear"></i>
                </a>
            </li>
        </ul>
        <!-- / navbar right -->

        <!-- navbar collapse -->
        <div class="collapse navbar-toggleable-sm" id="collapse">
            <?php echo e(Form::open(['route' => ['adminFind'],'method' => 'POST','role' => 'search','class' => 'navbar-form form-inline pull-right pull-none-sm navbar-item v-m'])); ?>


            
            <?php echo e(Form::close()); ?>

            <!-- link and dropdown -->
            <?php if(@Auth::user()->permissionsGroup->add_status): ?>
                <ul class="nav navbar-nav">
                    <li class="nav-item dropdown">
                        <!-- <a class="nav-link" href data-toggle="dropdown">
                        <i class="fa fa-fw fa-plus text-muted"></i>
                        <span><?php echo e(__('backend.new')); ?> </span>
                    </a> -->
                        <div class="dropdown-menu dropdown-menu-scale">
                            <?php
                            $data_sections_arr = explode(',', Auth::user()->permissionsGroup->data_sections);
                            $clr_ary = ['info', 'danger', 'success', 'accent'];
                            $ik = 0;
                            $mnu_title_var = 'title_' . @Helper::currentLanguage()->code;
                            $mnu_title_var2 = 'title_' . env('DEFAULT_LANGUAGE');
                            ?>
                            <?php if(@Auth::user()->permissionsGroup->add_status): ?>

                                <div class="dropdown-divider"></div>

                                <?php if(Helper::GeneralWebmasterSettings('newsletter_status')): ?>
                                    <?php if(@Auth::user()->permissionsGroup->newsletter_status): ?>
                                        <a class="dropdown-item" href="<?php echo e(route('contacts')); ?>"><i
                                                class="material-icons">
                                                &#xe7ef;</i>
                                            &nbsp;<?php echo e(__('backend.newContacts')); ?></a>
                                    <?php endif; ?>
                                <?php endif; ?>
                            <?php endif; ?>
                            <?php if(Helper::GeneralWebmasterSettings('inbox_status')): ?>
                                <?php if(@Auth::user()->permissionsGroup->inbox_status): ?>
                                    <a class="dropdown-item"
                                        href="<?php echo e(route('webmails', ['group_id' => 'create'])); ?>"><i
                                            class="material-icons">&#xe0be;</i> &nbsp;<?php echo e(__('backend.compose')); ?>

                                    </a>
                                <?php endif; ?>
                            <?php endif; ?>

                        </div>
                    </li>
                </ul>
            <?php endif; ?>
            <!-- / -->
        </div>
        <!-- / navbar collapse -->
    </div>
</div>
<?php /**PATH /home/netcofin/public_html/resources/views/dashboard/layouts/header.blade.php ENDPATH**/ ?>