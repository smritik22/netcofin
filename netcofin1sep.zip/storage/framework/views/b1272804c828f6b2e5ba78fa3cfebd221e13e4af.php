<?php
$title_var = "title_" . @Helper::currentLanguage()->code;
$title_var2 = "title_" . env('DEFAULT_LANGUAGE');
?>
<?php $__env->startSection('title', __('backend.cms')); ?>
<?php $__env->startPush("after-styles"); ?>
    <link href="<?php echo e(asset(' assets/dashboard/js/iconpicker/fontawesome-iconpicker.min.css')); ?>" rel="stylesheet">

    <link rel= "stylesheet" href= "https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.9.0/css/bootstrap-datepicker.min.css" />

    <!--[if lt IE 9]>
    <script src="//html5shim.googlecode.com/svn/trunk/html5.js"></script>
    <![endif]-->

    <style type="text/css">
        .error {
            color: red;
            margin-left: 5px;
        }
    </style>
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
    <div class="padding edit-package">
        <div class="box">
            <div class="box-header dker">
                <?php
                $title_var = "title_" . @Helper::currentLanguage()->code;
                $title_var2 = "title_" . env('DEFAULT_LANGUAGE');
                ?>
                <h3><i class="material-icons">
                        &#xe02e;</i> <?php echo e(__('backend.topicNew')); ?> <?php echo e(__('backend.cms')); ?>

                </h3>
                <small>
                    <a href="<?php echo e(route('adminHome')); ?>"><?php echo e(__('backend.home')); ?></a> /
                    <a href="<?php echo e(route('cms')); ?>"><?php echo e(__('backend.cms')); ?></a>
                </small>
            </div>
            <div class="box-tool">
                <ul class="nav">
                    <li class="nav-item inline">
                        <a class="nav-link" href="<?php echo e(route('cms')); ?>">
                            <i class="material-icons md-18">×</i>
                        </a>
                    </li>
                </ul>
            </div>
            <div class="box-body">
                <?php echo e(Form::open(['route'=>['cms.store'],'method'=>'POST', 'files' => true,'enctype' => 'multipart/form-data', 'id' => 'cmsForm' ])); ?>


                <div class="personal_informations">
                    <!-- <h3><?php echo __('backend.cms'); ?></h3>
                    <br>
                    <br> -->
                    <div class="form-group row">
                        <cms class="col-sm-2 form-control-cms">Page Name</cms>
                        <div class="col-sm-10">
                            <input type="text" name="page_name" id="page_name" class="form-control" placeholder="Name" value="">
                        </div>
                    </div>

                    <div class="form-group row">
                        <cms class="col-sm-2 form-control-cms">Page Content</cms>
                        <div class="col-sm-10">
                            <textarea class="form-control" id="page_content" name="page_content" autofocus ></textarea>
                        </div>
                    </div>
                </div>

                    <div class="form-group row m-t-md">
                        <div class="offset-sm-2 col-sm-10">
                            <button type="submit" class="btn btn-primary m-t" id="submitDetail"><i class="material-icons">&#xe31b;</i> <?php echo __('backend.add'); ?></button>
                            <a href="<?php echo e(route('cms')); ?>" class="btn btn-default m-t">
                                <i class="material-icons">
                                &#xe5cd;</i> <?php echo __('backend.cancel'); ?>

                            </a>
                    </div>
                </div>


                <?php echo e(Form::close()); ?>

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush("after-scripts"); ?>
    <script src="<?php echo e(asset("assets/dashboard/js/iconpicker/fontawesome-iconpicker.js")); ?>"></script>
    <script src="<?php echo e(asset("assets/dashboard/js/summernote/dist/summernote.js")); ?>"></script>
    <script src= "https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.9.0/js/bootstrap-datepicker.min.js"></script>

 

    <script>
        $(function () {
            $('.icp-auto').iconpicker({placement: '<?php echo e((@Helper::currentLanguage()->direction=="rtl")?"topLeft":"topRight"); ?>'});
        });

        
        // update progress bar
        function progressHandlingFunction(e) {
            if (e.lengthComputable) {
                $('progress').attr({value: e.loaded, max: e.total});
                // reset progress on complete
                if (e.loaded == e.total) {
                    $('progress').attr('value', '0.0');
                }
            }
        }
    </script>
    <script>
            

        CKEDITOR.replace('page_content');
        
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('dashboard.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/netcofin/public_html/resources/views/dashboard/cms/create.blade.php ENDPATH**/ ?>