<?php $__env->startSection('title', __('backend.additems')); ?>
<?php $__env->startPush("after-styles"); ?>
    <link href="<?php echo e(asset("assets/dashboard/js/iconpicker/fontawesome-iconpicker.min.css")); ?>" rel="stylesheet">

    <link rel= "stylesheet" href= "https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.9.0/css/bootstrap-datepicker.min.css" />

    <style type="text/css">
        .error {
            color: red;
            margin-left: 5px;
        }
    </style>
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
    <div class="padding edit-package">
        <div class="box">
            <div class="box-header dker">
                <h3><i class="material-icons">
                        &#xe02e;</i> <?php echo e(__('backend.additems')); ?>

                </h3>
                <small>
                    <a href="<?php echo e(route('adminHome')); ?>"><?php echo e(__('backend.home')); ?></a> /
                    <span><?php echo e(__('backend.additems')); ?></span>

                </small>
            </div>
            <div class="box-body">
                <?php echo e(Form::open(['route'=>['item.store'],'method'=>'POST', 'files' => true,'enctype' => 'multipart/form-data', 'id' => 'userForm' ])); ?>

                <?php echo e(csrf_field()); ?>

                <div class="personal_informations">

                    <div class="form-group row">
                        <label class="col-sm-2 form-control-label"><?php echo __('backend.topicName'); ?></label>
                        <div class="col-sm-10">
                            <input type="text" name="name" id="name" class="form-control"
                                placeholder="<?php echo e(__('backend.topicName')); ?>" >
                            <span class="help-block">
                                <?php if(!empty(@$errors) && @$errors->has('name')): ?>
                                    <span  style="color: red;" class='validate'><?php echo e($errors->first('name')); ?></span>
                                <?php endif; ?>
                            </span>
                        </div>
                    </div>


                    <div class="form-group row">
                        <label class="col-sm-2 form-control-label"><?php echo __('backend.business_owner'); ?></label>
                        <div class="col-sm-10">
                            <select name="business_owner" id="business_owner" value="" class="form-control">
                            <option value=>Select Business Owner</option>
                                <?php $__currentLoopData = $business_owners; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($value->id); ?>" ><?php echo e($value->full_name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <span class="help-block">
                                <?php if(!empty(@$errors) && @$errors->has('business_owner')): ?>
                                    <span  style="color: red;" class='validate'><?php echo e($errors->first('business_owner')); ?></span>
                                <?php endif; ?>
                            </span>
                        </div>
                    </div>

                    <div class="form-group row">
                        <label class="col-sm-2 form-control-label"><?php echo __('backend.category'); ?></label>
                        <div class="col-sm-4">
                            <select name="category" id="category" value="" class="form-control">
                                
                            </select>
                            <span class="help-block">
                                <?php if(!empty(@$errors) && @$errors->has('category')): ?>
                                    <span  style="color: red;" class='validate'><?php echo e($errors->first('category')); ?></span>
                                <?php endif; ?>
                            </span>
                        </div>
                        <label class="col-sm-2 form-control-label"><?php echo __('backend.subCategory'); ?></label>
                        <div class="col-sm-4">
                            <select name="subcategory" id="subcategory" value="" class="form-control">
                               
                            </select>
                            <span class="help-block">
                                <?php if(!empty(@$errors) && @$errors->has('subcategory')): ?>
                                    <span  style="color: red;" class='validate'><?php echo e($errors->first('subcategory')); ?></span>
                                <?php endif; ?>
                            </span>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label class="col-sm-2 form-control-label"><?php echo __('backend.price'); ?></label>
                        <div class="col-sm-4">
                            <input type="text" name="price" id="price" class="form-control"
                                placeholder="<?php echo e(__('backend.price')); ?>" >
                            <span class="help-block">
                                <?php if(!empty(@$errors) && @$errors->has('price')): ?>
                                    <span  style="color: red;" class='validate'><?php echo e($errors->first('price')); ?></span>
                                <?php endif; ?>
                            </span>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label class="col-sm-2 form-control-label"><?php echo __('backend.description'); ?></label>
                        <div class="col-sm-10">
                            <textarea name="description" id="description" class="form-control" rows="5" placeholder="<?php echo e(__('backend.description')); ?>"><?php echo e(old('description')); ?></textarea>

                            <span class="help-block">
                                <?php if(!empty(@$errors) && @$errors->has('description')): ?>
                                    <span style="color: red;" class='validate'><?php echo e($errors->first('description')); ?></span>
                                <?php endif; ?>
                            </span>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label for="photo_file" class="col-sm-2 form-control-label"><?php echo __('backend.image'); ?></label>
                        <div class="col-sm-10">
                            <?php echo Form::file('image', ['class' => 'form-control', 'id' => 'image', 'accept' => 'image/*']); ?>

                            <small>
                                <i class="material-icons">&#xe8fd;</i>
                                <?php echo __('backend.imagesTypes'); ?>

                            </small>
                            <br>
                            <span class="help-block">
                                <?php if(!empty(@$errors) && @$errors->has('image')): ?>
                                    <span  style="color: red;" class='validate'><?php echo e($errors->first('image')); ?></span>
                                <?php endif; ?>
                            </span>
                        </div>
                    </div>

                    <div class="form-group row m-t-md">
                        <div class="offset-sm-2 col-sm-10">
                            <button type="submit" class="btn btn-primary m-t" id="submitDetail"><i class="material-icons">&#xe31b;</i> <?php echo __('backend.add'); ?></button>
                            <a href="<?php echo e(route('items')); ?>" class="btn btn-default m-t">
                                <i class="material-icons">
                                &#xe5cd;</i> <?php echo __('backend.cancel'); ?>

                            </a>
                    </div>
                </div>


                <?php echo e(Form::close()); ?>

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush("after-scripts"); ?>
    <script src="<?php echo e(asset('assets/dashboard/js/iconpicker/fontawesome-iconpicker.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/dashboard/js/summernote/dist/summernote.js')); ?>"></script>
    <script src= "https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.9.0/js/bootstrap-datepicker.min.js"></script>
    <script src="<?php echo e(asset('assets/dashboard/js/inputFilter.js')); ?>"></script>


    <script>
        $(function () {
            $('.icp-auto').iconpicker({placement: '<?php echo e((@Helper::currentLanguage()->direction=="rtl")?"topLeft":"topRight"); ?>'});
        });

        // update progress bar
        function progressHandlingFunction(e) {
            if (e.lengthComputable) {
                $('progress').attr({value: e.loaded, max: e.total});
                // reset progress on complete
                if (e.loaded == e.total) {
                    $('progress').attr('value', '0.0');
                }
            }
        }


        $(document).ready(function() {
            $("#mobile_number").inputFilter(function(value) {
              return /^\d*$/.test(value);    // Allow digits only, using a RegExp
            });
            $("#business_owner").change(function()
            {
                var id=$(this).val();
                console.log("1:"+id);

                var dataString = {'id':id};
                console.log("2:"+dataString);
                $.ajax
                ({
                type: "POST",
                url: "<?php echo e(route('item.categories')); ?>",
                data: {'id':id},
                cache: false,
                success: function(data)
                {
                console.log("3:"+data);
                    $('#category').empty().append(JSON.parse(data));
                } 
                });

            });
            $("#category").change(function()
            {
                var id=$(this).val();
                var busineowner_id=$('#business_owner').val();
                console.log("1:"+id);

                var dataString = {'busineowner_id':busineowner_id,'id':id};
                console.log("2:"+dataString);
                $.ajax
                ({
                type: "POST",
                url: "<?php echo e(route('item.subcategories')); ?>",
                data: {'id':id},
                cache: false,
                success: function(data)
                {
                console.log("3:"+data);
                    $('#subcategory').empty().append(JSON.parse(data));
                } 
                });

            });
        });

    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('dashboard.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/netcofin/public_html/resources/views/dashboard/items/create.blade.php ENDPATH**/ ?>