<?php if(Helper::GeneralWebmasterSettings("register_status")): ?>
    
    <?php $__env->startSection('title', __('backend.createNewAccount')); ?>
<?php $__env->startSection('content'); ?>
    <div class="center-block w-xxl p-t-3">
        <div class="p-a-md box-color r box-shadow-z4 text-color">
            <div class="text-center">
                <?php if(Helper::GeneralSiteSettings("style_logo_" . @Helper::currentLanguage()->code) !=""): ?>
                    <img alt="" class="app-logo"
                         src="<?php echo e(URL::to('uploads/settings/'.Helper::GeneralSiteSettings("style_logo_" . @Helper::currentLanguage()->code))); ?>">
                <?php else: ?>
                    <img alt="" src="<?php echo e(URL::to('uploads/settings/nologo.png')); ?>">
                <?php endif; ?>
            </div>
            <div class="m-y text-muted text-center">
                <?php echo e(__('backend.newUser')); ?>

            </div>
            <form role="form" method="POST" action="<?php echo e(route('register')); ?>">
                <?php echo e(csrf_field()); ?>


                <?php if($errors->has('name')): ?>
                    <div class="alert alert-warning">
                        <?php echo e($errors->first('name')); ?>

                    </div>
                <?php endif; ?>
                <?php if($errors->has('email')): ?>
                    <div class="alert alert-warning">
                        <?php echo e($errors->first('email')); ?>

                    </div>
                <?php endif; ?>
                <?php if($errors->has('password')): ?>
                    <div class="alert alert-warning">
                        <?php echo e($errors->first('password')); ?>

                    </div>
                <?php endif; ?>
                <div class="md-form-group">
                    <input id="name" type="text" class="md-input" name="name" value="<?php echo e(old('name')); ?>" required
                           autofocus>
                    <label><?php echo e(__('backend.fullName')); ?></label>
                </div>
                <div class="md-form-group">
                    <input id="email" type="email" class="md-input" name="email" value="<?php echo e(old('email')); ?>" required>

                    <label><?php echo e(__('backend.connectEmail')); ?></label>
                </div>
                <div class="md-form-group">
                    <input id="password" type="password" class="md-input" name="password" required>
                    <label><?php echo e(__('backend.connectPassword')); ?></label>
                </div>
                <div class="md-form-group">
                    <input id="password-confirm" type="password" class="md-input" name="password_confirmation" required>
                    <label><?php echo e(__('backend.confirmPassword')); ?></label>
                </div>

                <button type="submit" class="btn primary btn-block p-x-md"><i
                        class="material-icons">&#xe7fe;</i> <?php echo e(__('backend.createNewAccount')); ?></button>
            </form>

            <div class="p-v-lg text-center m-t-1">
                <div><?php echo e(__('backend.signedInToControl')); ?> <a href="<?php echo e(url('/'.env('BACKEND_PATH').'/login')); ?>"
                                                              class="text-primary _600"><?php echo e(__('backend.signIn')); ?></a>
                </div>
            </div>
        </div>

    </div>
<?php $__env->stopSection(); ?>
<?php else: ?>
    <script>
        window.location.href = '<?php echo e(url("/login")); ?>';
    </script>
<?php endif; ?>


<?php echo $__env->make('dashboard.layouts.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/netcofin/public_html/resources/views/auth/register.blade.php ENDPATH**/ ?>