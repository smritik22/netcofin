<?php $__env->startSection('title', __('backend.forgotPassword')); ?>
<?php $__env->startSection('content'); ?>
    <div class="center-block w-xxl p-t-3">
        <div class="p-a-md box-color r box-shadow-z4 text-color">
            <div class="text-center">
                <img class="logo-img" alt="" src="<?php echo e(asset('assets/frontend/logo/Logo_White.jpg')); ?>">
            </div>
            <div class="m-y text-muted text-center">
                <?php echo e(__('backend.forgotPassword')); ?>

            </div>
            <div class="text-muted text-left">
                <p class="text-xs m-t"><?php echo e(__('backend.enterYourEmail')); ?></p>
            </div>
            <?php if(session('status')): ?>
                <div class="alert alert-success">
                    <?php echo e(session('status')); ?>

                </div>
            <?php endif; ?>
             <?php if(session('success')): ?>
                <div class="alert alert-success">
                    <?php echo e(session('success')); ?>

                </div>
            <?php endif; ?>

            <form name="reset" method="POST" action="<?php echo e(url('/'.env('BACKEND_PATH').'/forgot/user')); ?>">
                <?php echo e(csrf_field()); ?>

                <div class="md-form-group <?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
                    <input type="email" name="email" value="<?php echo e(old('email')); ?>" class="md-input" required>
                    <label><?php echo e(__('backend.yourEmail')); ?></label>
                </div>
                <?php if($errors->has('email')): ?>
                    <div class="alert alert-danger">
                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                            <span aria-hidden="true">×</span>
                        </button>
                        <?php echo e($errors->first('email')); ?>

                    </div>
                <?php endif; ?>
                <button type="submit"
                        class="btn primary btn-block p-x-md"><?php echo e(__('backend.sendPasswordResetLink')); ?></button>
            </form>

            <p id="alerts-container"></p>
            <div class="p-v-lg text-center"><?php echo e(__('backend.returnTo')); ?> <a href="<?php echo e(url('/'.env('BACKEND_PATH').'/login')); ?>"
                                                                            class="text-primary _600"><?php echo e(__('backend.signIn')); ?></a>
        </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('dashboard.layouts.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/netcofin/public_html/resources/views/auth/passwords/email.blade.php ENDPATH**/ ?>