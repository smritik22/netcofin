<?php $__env->startSection('title','Dashboard'); ?>
<?php $__env->startPush("after-styles"); ?>
    <link rel="stylesheet" href="<?php echo e(asset('assets/dashboard/css/flags.css')); ?>" type="text/css"/>
    <style>
        .upskild-dashboard .card-graphs canvas.chartjs-render-monitor {
            height: 400px !important;
        }
    </style>
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
<?php 
use App\Models\User;
?>
    <div class="padding p-b-0 upskild-dashboard">
        <div class="margin">
            <div class="row">
                 <div class="col-xs-6">
                <h5 class="m-b-0 _300"><?php echo e(__('backend.hi')); ?> <span
                        class="text-primary"><?php echo e(Auth::user()->name); ?></span>, <?php echo e(__('backend.welcomeBack')); ?>

                </h5>
                </div>
                 <div class="col-xs-6">
                <form action="<?php echo e(route('dashboardfilter')); ?>" method="post" style="padding-left: %;">
                    <?php echo csrf_field(); ?>
                    <input type="text" name="start_date" id="start_date" class="form-control" placeholder="Start Date" required="required" value="<?php echo isset($start) ? $start : ''; ?>" style="color: #001645;font-weight:500;width: 200px;margin-right: 8px;">
                        <input type="text" name="end_date" id="end_date" class="form-control" placeholder="End Date" required="required" value="<?php echo isset($end) ? $end : ''; ?>" style="color: #001645;font-weight:500;width: 200px;margin-right: 8px;" >    
                       
                        <input type="submit" name="filter_submit" class="btn btn-primary" value="Filter" />
                        <a href="<?php echo e(route('adminHome')); ?>"><input type="button" name="clear" class="btn btn-danger" value="Clear"  /></a>
                </form>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-sm-12 col-md-12 col-lg-12">
                <div class="row">
                
                    <div class="col-xs-4">
                        <div class="box p-a" style="cursor: pointer">
                            <a href="<?php echo e(route('generalusers')); ?>">
                                <div class="pull-left m-r">
                                   <i class="fa fa-users material-icons text-2x m-y-sm" aria-hidden="true"></i>
                                </div>
                                <div class="clear">
                                    <div class="text-muted">Users Registered</div>
                                        <h4 class="m-a-0 text-md _600"><?php echo e(isset($total_users) ? $total_users : ''); ?></h4>
                                </div>
                            </a>
                        </div>
                    </div>
                    <div class="col-xs-4">
                        <div class="box p-a" style="cursor: pointer">
                            <a href="<?php echo e(route('subscription_plans')); ?>">
                                <div class="pull-left m-r">
                                    <i class="fa fa-rocket material-icons  text-2x m-y-sm" aria-hidden="true"></i>
                                </div>
                                <div class="clear">
                                    <div class="text-muted">Total Subscription Plans</div>
                                        <h4 class="m-a-0 text-md _600"><?php echo e(isset($subscriptions_number) ? $subscriptions_number : ''); ?></h4>
                                </div>
                            </a>
                        </div>
                    </div>

                    <div class="col-xs-4">
                        <div class="box p-a" style="cursor: pointer">
                            <a href="<?php echo e(route('revenue_report')); ?>">
                                <div class="pull-left m-r">
                                    <i class="fa fa-money-bill-wave material-icons  text-2x m-y-sm" aria-hidden="true"></i>
                                </div>
                                <div class="clear">
                                    <div class="text-muted">Total Revenue Generated</div>
                                        <h4 class="m-a-0 text-md _600"><?php echo e((isset($revenue_generated) && $revenue_generated > 0) ? $revenue_generated : '0' . ' ' . Helper::getDefaultCurrency()); ?>$</h4>
                                </div>
                            </a>
                        </div>
                    </div>
                    
                    <div class="col-xs-12">
                       
                    </div>
                </div>
            </div>
            <div class="col-sm-12 col-md-12 col-lg-12">
                <div class="row">
                
                    <div class="col-xs-4">
                        <div class="box p-a" style="cursor: pointer">
                            <a href="<?php echo e(route('businessOwners')); ?>">
                                <div class="pull-left m-r">
                                   <i class="fa fa-users material-icons text-2x m-y-sm" aria-hidden="true"></i>
                                </div>
                                <div class="clear">
                                    <div class="text-muted"><?php echo e(__('backend.business_owner')); ?></div>
                                        <h4 class="m-a-0 text-md _600"><?php echo e(isset($total_busineowners) ? $total_busineowners : ''); ?></h4>
                                </div>
                            </a>
                        </div>
                    </div>
                    <div class="col-xs-4">
                        <div class="box p-a" style="cursor: pointer">
                            <a href="<?php echo e(route('categories')); ?>">
                                <div class="pull-left m-r">
                                    <i class="fa fa-rocket material-icons  text-2x m-y-sm" aria-hidden="true"></i>
                                </div>
                                <div class="clear">
                                    <div class="text-muted"><?php echo e(__('backend.categories')); ?></div>
                                        <h4 class="m-a-0 text-md _600"><?php echo e(isset($total_categories) ? $total_categories : ''); ?></h4>
                                </div>
                            </a>
                        </div>
                    </div>

                    <div class="col-xs-4">
                        <div class="box p-a" style="cursor: pointer">
                            <a href="<?php echo e(route('sub-categories')); ?>">
                                <div class="pull-left m-r">
                                    <i class="fa fa-money-bill-wave material-icons  text-2x m-y-sm" aria-hidden="true"></i>
                                </div>
                                <div class="clear">
                                    <div class="text-muted"><?php echo e(__('backend.subCategory')); ?></div>
                                        <h4 class="m-a-0 text-md _600"><?php echo e(isset($total_subcategories) ? $total_subcategories : ''); ?></h4>
                                </div>
                            </a>
                        </div>
                    </div>
                    
                    <div class="col-xs-12">
                       
                    </div>
                </div>
            </div>
            <div class="col-sm-12 col-md-12 col-lg-12">
                <div class="row">
                    <div class="col-xs-6">
                        <div class="card-head">
                            <h6>Users</h6>
                        </div>
                         <div  style="width: 300px; height: 300px; " class="card-graphs">
                           <?php echo $userProfileGraph->container(); ?>

                            <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.7.1/Chart.min.js" charset="utf-8"></script>
                            <?php echo $userProfileGraph->script(); ?>

                        </div>
                    </div>
                    <div class="col-xs-6">
                        <div class="card-head">
                            <h6>Total Revenue</h6>
                        </div>
                         <div  style="width: 600px; height: 300px; " class="card-graphs card-cart">
                           <?php echo $revenueChart->container(); ?>

                            <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.7.1/Chart.min.js" charset="utf-8"></script>
                            <?php echo $revenueChart->script(); ?>

                        </div>
                    </div>
                    
                </div>
            </div>

            <div class="col-sm-12 col-md-12 col-lg-12">
                <div class="row">
                    <div class="card-head">
                        <h6>Registered <?php echo e(__('backend.business_owner')); ?></h6>
                    </div>
                        <div  style="width: 600px; height: 300px; " class="card-graphs card-cart">
                           <?php echo $businessownerChart->container(); ?>

                            <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.7.1/Chart.min.js" charset="utf-8"></script>
                            <?php echo $businessownerChart->script(); ?>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush("after-scripts"); ?>


<link href="https://unpkg.com/bootstrap-datepicker@1.9.0/dist/css/bootstrap-datepicker3.min.css" rel="stylesheet"/>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
<script src="https://unpkg.com/bootstrap-datepicker@1.9.0/dist/js/bootstrap-datepicker.min.js"></script>
<script type="text/javascript" src="https://cdn.jsdelivr.net/momentjs/latest/moment.min.js"></script>
<script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>

    <script type="text/javascript">
        $("#start_date").datepicker({
            format: 'dd-mm-yyyy',
        });

        $("#end_date").datepicker({
            format: 'dd-mm-yyyy',
        });
    </script>  
<?php $__env->stopPush(); ?>
<?php echo $__env->make('dashboard.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/netcofin/public_html/resources/views/dashboard/home.blade.php ENDPATH**/ ?>