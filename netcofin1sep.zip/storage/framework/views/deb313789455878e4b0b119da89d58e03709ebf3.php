<?php $__env->startSection('content'); ?>

<!-- Banner -->
<section class="internal_banner">
    <div class="container">
        <div class="row">
            <div class="col-12">
                <div class="banner_content">
                    <h1><?php echo e(__('backend.register')); ?></h1>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- Banner -->

<!-- Contact Section -->
<section class="common_padding contact_page">
    <div class="container">
        <div>
            <?php if(Session::has('success')): ?>
                <div class="alert alert-success text-center">
                    <p><?php echo e(Session::get('success')); ?></p>
                </div>
            <?php endif; ?>
        </div>
        <div class="row">
            <?php if(count($plans_data)  > 0): ?>
            <div class="col-md-4">
                <div class="plan_box plan_box_register">
                    <h5><?php echo e(__('backend.planinfo')); ?></h5>
                    <h3><?php echo e($plans_data[0]->plan_name); ?></h3>
                    <?php
                            $duration = \Helper::getValidTillDate(date('Y-m-d H:i:s'),$plans_data[0]->plan_duration_value, $plans_data[0]->plan_duration_type);
                    ?>
                    <div class="plan_type">
                        <?php if(!$plans_data[0]->is_free_plan && $plans_data[0]->plan_price != '0.00'): ?>
                        <h3><?php echo e(\Helper::getDefaultCurrency().$plans_data[0]->plan_price); ?><span>/<?php echo e($duration['value'] . ' ' . $duration['label_value']); ?></span></h3>
                        <?php else: ?>
                        <h3>Free</h3>
                        <?php endif; ?>
                    </div>
                    <!-- <p>Limited Access</p> -->
                    <ul>
                        <li><?php echo e($plans_data[0]->plan_description); ?></li>
                    </ul>
                    <div class="bottom_btn">
                        <a href="<?php echo e(route('frontend.planlist')); ?>" class="common_btn transparent">CHANGE PLAN</a>
                    </div>
                </div>
            </div>
            <?php endif; ?>
            <div class="col-md-8">
                <div class="register_form">
                <form name="register_form" enctype="multipart/form-data" method="POST" action="<?php echo e(URL('/register/submit')); ?>" class="needs-validation" novalidate id="payment-form" >
                    <div id="hidden_values">
                        
                    </div>
                    <div class="row">
                        <div class="col-12">
                            <h3><?php echo e(__('backend.ownerifo')); ?></h3>
                        </div>
                        <div class="col-md-12">
                            <div class="input-group has-validation">
                                <input type="text" name="fullname" id="fullname" placeholder="Full name" required="" value="<?php echo e(old('fullname')); ?>" class="form-control">
                                <div class="invalid-feedback"> Please Enter Full Name.</div>
                                <?php if(!empty(@$errors) && @$errors->has('fullname')): ?>
                                    <div class='invalid-feedback' style="display:block"><?php echo e($errors->first('fullname')); ?></div>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="input-group has-validation">
                            <input type="email" name="email" id="email" placeholder="Email" required="" value="<?php echo e(old('email')); ?>" class="form-control">
                                <div class="invalid-feedback"> Please Enter Email Address.</div>
                                <?php if(!empty(@$errors) && @$errors->has('email')): ?>
                                    <div class='invalid-feedback' style="display:block"><?php echo e($errors->first('email')); ?></div>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="input-group has-validation">
                                <input type="text" name="businessOwner" id="businessOwner" placeholder="Business Owner Name" required="" value="<?php echo e(old('businessOwner')); ?>" class="form-control">
                                <div class="invalid-feedback"> Please Enter Owner Name.</div>
                                <?php if(!empty(@$errors) && @$errors->has('businessOwner')): ?>
                                    <div class='invalid-feedback' style="display:block"><?php echo e($errors->first('businessOwner')); ?></div>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="col-12">
                            <div class="input-group has-validation">
                            <input type="text" name="mobile" id="mobile" onKeyPress="if(this.value.length==16) return false;"  placeholder="<?php echo e($labels['mobile_number']); ?>" data-error="#mobile_error" required="" value="<?php echo e(old('mobile')); ?>" class="form-control">
                                <div class="invalid-feedback"> Please Enter Phone Number.</div>
                                <?php if(!empty(@$errors) && @$errors->has('mobile')): ?>
                                    <div class='invalid-feedback' style="display:block"><?php echo e($errors->first('mobile')); ?></div>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="col-12">
                            <div class="billing">
                                <h3>Billing Information</h3>
                            </div>
                        </div>
                            <div class="col-md-12">
                                <div class="input-group has-validation">
                                    <textarea name="address" rows="2" id="address" data-error="#address_error" placeholder="Enter your address" class="form-control"><?php echo e(old('address') ?  old('address') : ''); ?></textarea>
                                    
                                    <div class="invalid-feedback"> Please Enter Address.</div>
                                    <?php if(!empty(@$errors) && @$errors->has('address')): ?>
                                        <div class='invalid-feedback' style="display:block"><?php echo e($errors->first('address')); ?></div>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="input-group">
                                    <select class="form-select" required="" name="country" id="country">
                                        <option selected disabled value="">Country</option>
                                        <?php if(count($countries) > 0): ?>
                                            <?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($value->id); ?>" <?php echo e(old('country') ? "selected" : ""); ?>><?php echo e($value->name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endif; ?>
                                    </select>
                                    <?php if(!empty(@$errors) && @$errors->has('country')): ?>
                                        <div class='invalid-feedback' style="display:block"><?php echo e($errors->first('country')); ?></div>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="input-group">
                                    <select class="form-select"  required="" name="state" id="state">
                                        <option selected disabled value="" <?php echo e(old('state') ? "selected" : ""); ?>>State</option>
                                        
                                    </select>
                                    <?php if(!empty(@$errors) && @$errors->has('state')): ?>
                                        <div class='invalid-feedback' style="display:block"><?php echo e($errors->first('state')); ?></div>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="input-group">
                                <select class="form-select"  required="" name="city" id="city">
                                        <option selected disabled value="" <?php echo e(old('city') ? "selected" : ""); ?>>City</option>
                                        
                                    </select>
                                    <?php if(!empty(@$errors) && @$errors->has('city')): ?>
                                        <div class='invalid-feedback' style="display:block"><?php echo e($errors->first('city')); ?></div>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="input-group has-validation">
                                    <input type="text" name="zipcode" id="zipcode" placeholder="Zip Code" required="" class="form-control" value="<?php echo e(old('zipcode')); ?>">
                                    <div class="invalid-feedback"> Please Enter Zip Code</div>
                                    <?php if(!empty(@$errors) && @$errors->has('zipcode')): ?>
                                        <span  style="color: red;" class='validate'><?php echo e($errors->first('zipcode')); ?></span>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="col-12">
                                <div class="billing">
                                    <h3>Payment Details</h3>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="input-group has-validation">
                                    <input type="number" name="card_number" id="card_number" placeholder="Card Number" required="" class="form-control" value="<?php echo e(old('card_number')); ?>">
                                    <div class="invalid-feedback"> Please Enter Card Number</div>
                                    <?php if(!empty(@$errors) && @$errors->has('card_number')): ?>
                                        <span  style="color: red;" class='validate'><?php echo e($errors->first('card_number')); ?></span>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="input-group has-validation">
                                    <input type="number" name="cvc" id="cvc" placeholder="CVC" required="" class="form-control" value="<?php echo e(old('cvc')); ?>">
                                    <div class="invalid-feedback"> Please Enter CVC</div>
                                </div>
                                <?php if(!empty(@$errors) && @$errors->has('cvc')): ?>
                                    <span  style="color: red;" class='validate'><?php echo e($errors->first('cvc')); ?></span>
                                <?php endif; ?>
                            </div>
                            <div class="col-md-6">
                                <div class="input-group has-validation">
                                    <input type="number" name="exp_month" id="exp_month" value="<?php echo e(old('exp_month')); ?>" placeholder="Expiration Month" required="" class="form-control">
                                    <div class="invalid-feedback"> Please Enter Expiration Month</div>
                                </div>
                                    <?php if(!empty(@$errors) && @$errors->has('exp_month')): ?>
                                        <span  style="color: red;" class='validate'><?php echo e($errors->first('exp_month')); ?></span>
                                    <?php endif; ?>
                            </div>
                            <div class="col-md-6">
                                <div class="input-group has-validation">
                                    <input type="number" name="exp_year" id="exp_year" value="<?php echo e(old('exp_year')); ?>" placeholder="Expiration Year" required="" class="form-control">
                                    <div class="invalid-feedback"> Please Enter Expiration Year</div>
                                    <?php if(!empty(@$errors) && @$errors->has('exp_year')): ?>
                                        <span  style="color: red;" class='validate'><?php echo e($errors->first('exp_year')); ?></span>
                                    <?php endif; ?>
                                </div>
                            </div>
                        
                        <div class="col-12">
                                <div class="form_checkbox">
                                    <div class="form-check">
                                        <input class="form-check-input" name="privacy_policy" type="checkbox" value="1" id="flexCheckDefault" required="">
                                        <label class="form-check-label" for="flexCheckDefault">
                                            <p>I accept the <a href="<?php echo e(route('frontend.privacy_policy')); ?>">Privacy Policy</a> and <a href="<?php echo e(route('frontend.terms_and_conditions')); ?>">Terms &amp; Conditions</a></p>
                                        </label>
                                        <div class="invalid-feedback">You must agree before submitting.</div>
                                    </div>
                                </div>
                        </div>
                        <div class="col-12 col-sm-12 col-md-12 col-lg-12">
                            <div class="form_btn">
                                <button type="submit" class="common_btn" id="submit_register" >Submit</button>
                            </div>
                        </div>
                    </div>
                </form>
                </div>
    </div>
</section>
<!-- Contact Section -->

<?php $__env->stopSection(); ?>
<?php $__env->startPush('after-scripts'); ?>
<script type="text/javascript" src="https://js.stripe.com/v2/"></script>
<script type="text/javascript">
// Example starter JavaScript for disabling form submissions if there are invalid fields
    (() => {
        'use strict'



        // Fetch all the forms we want to apply custom Bootstrap validation styles to
        const forms = document.querySelectorAll('.needs-validation')



        // Loop over them and prevent submission
        Array.from(forms).forEach(form => {
        form.addEventListener('submit', event => {
            if (!form.checkValidity()) {
            event.preventDefault()
            event.stopPropagation()
            }



            form.classList.add('was-validated')
        }, false)
        })
    })()
    // 
    $(document).ready(function() {
        $('#fullname').on("input", function () {
            $(this).val($(this).val().replace(/^\s+/g, ''));
        });
        $('#mobile').on("input", function () {
            this.value = this.value.replace(/[^0-9\.]/g,''); 
            $(this).val($(this).val().replace(/^\s+/g, ''));
        });
        $('#zipcode').on("input", function () {
            this.value = this.value.replace(/[^0-9\.]/g,''); 
            $(this).val($(this).val().replace(/^\s+/g, ''));
        });
        $('#email').on("input", function () {
            $(this).val($(this).val().replace(/^\s+/g, ''));
        });

        $("#country").change(function()
        {
            var id=$(this).val();
            var country_id=$('#country').val();
            console.log("1:"+id);

            var dataString = {'country_id':country_id,'id':id};
            console.log("2:"+dataString);
            $.ajax
            ({
            type: "POST",
            url: "<?php echo e(route('frontend.getState')); ?>",
            data: {'id':id},
            cache: false,
            success: function(data)
            {
            console.log("3:"+data);
                $('#state').empty().append(JSON.parse(data));
            } 
            });

        });

        $("#state").change(function()
        {
            var id=$(this).val();
            var country_id=$('#country').val();
            console.log("1:"+id);

            var dataString = {'country_id':country_id,'id':id};
            console.log("2:"+dataString);
            $.ajax
            ({
            type: "POST",
            url: "<?php echo e(route('frontend.getCity')); ?>",
            data: {'id':id,'country_id':country_id},
            cache: false,
            success: function(data)
            {
            console.log("3:"+data);
                $('#city').empty().append(JSON.parse(data));
            } 
            });

        });

        // $("#submit_register").click(function(){
        //     if($('#card_number').val() != "" || $('#cvc').val() != "" || $('#exp_month').val() != "" || $('#exp_year').val() != ""){
        //         var $form         = $("#payment-form");
        //         var key = "<?php echo e(env('STRIPE_KEY')); ?>";
        //         Stripe.setPublishableKey(key);
        //             Stripe.createToken({
        //                 number: $('#card_number').val(),
        //                 cvc: $('#cvc').val(),
        //                 exp_month: $('#exp_month').val(),
        //                 exp_year: $('#exp_year').val()
        //             }, stripeResponseHandler);
        
        //         function stripeResponseHandler(status, response) {
        //             if (response.error) {
        //                 console.log(response.error.message);
        //             } else {
        //                 /* token contains id, last4, and card type */
        //                 console.log(response);
        //                 var token = response['id'];
        //                 // $form.find('input[type=text]').empty();
        //                 $form.append("<input type='hidden' name='stripeToken' value='" + token + "'/>");
        //                 $form.get(0).submit();
        //             }
        //         }
        //     }
        // // alert("The paragraph was clicked.");
        // });
    });
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('frontEnd.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/netcofin/resources/views/frontEnd/register.blade.php ENDPATH**/ ?>