<?php $__env->startSection('content'); ?>

    <!-- Banner -->
    <section class="internal_banner">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="banner_content">
                        <h1><?php echo e($labels['contact_us']); ?></h1>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- Banner -->
    <section class="inner-pading thank-you-outer">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="thank-you">
                       
                        <h1><?php echo e($labels['thanks_for_reaching_out']); ?></h1>
                        <p>
                            <?php echo $labels['thank_you_page_message_to_show']; ?>

                        </p>
                        <a href="<?php echo e(route('frontend.homePage')); ?>" class="comman-btn"><?php echo e($labels['back_to_home']); ?></a>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontEnd.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/netcofin/public_html/resources/views/frontEnd/thank_you.blade.php ENDPATH**/ ?>