<div class="tab-pane <?php echo e(Session::get('active_tab') == 'languageSettingsTab' || Session::get('active_tab') == '' ? 'active' : ''); ?>"
    id="tab-2">
    <div class="p-a-md">
        <h5><?php echo __('backend.languageSettings'); ?></h5>
    </div>

    <div class="p-a-md col-md-12">
        <div class="row">
            <div class="col-sm-6">
                <div class="form-group">
                    <label><?php echo e(__('backend.defaultLanguage')); ?> : </label>
                    <div>
                        <select name="languages_by_default" class="form-control c-select">
                            <?php $__currentLoopData = Helper::languagesList(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ActiveLanguage): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($ActiveLanguage->code); ?>"
                                        <?php echo e($WebmasterSetting->languages_by_default == $ActiveLanguage->code ? "selected='selected'" : ''); ?>>
                                        <?php echo e($ActiveLanguage->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                </div>
            </div>
            <div class="col-sm-6">
                <label><?php echo e(__('backend.dateFormat')); ?> : </label>
                <select name="date_format" class="form-control select2 select2-hidden-accessible" ui-jp="select2"
                    ui-options="{theme: 'bootstrap'}">
                    <option value="YY-mm-dd" <?php echo e(env('DATE_FORMAT', 'YY-mm-dd') == 'YY-mm-dd' ? 'selected' : ''); ?>>YY-mm-dd
                    </option>
                    <option value="dd-mm-YY" <?php echo e(env('DATE_FORMAT', 'YY-mm-dd') == 'dd-mm-YY' ? 'selected' : ''); ?>>dd-mm-YY
                    </option>
                    <option value="mm-dd-YY" <?php echo e(env('DATE_FORMAT', 'YY-mm-dd') == 'mm-dd-YY' ? 'selected' : ''); ?>>mm-dd-YY
                    </option>
                    <option value="dd/mm/YY" <?php echo e(env('DATE_FORMAT', 'YY-mm-dd') == 'dd/mm/YY' ? 'selected' : ''); ?>>dd/mm/YY
                    </option>
                    <option value="mm/dd/YY" <?php echo e(env('DATE_FORMAT', 'YY-mm-dd') == 'mm/dd/YY' ? 'selected' : ''); ?>>mm/dd/YY
                    </option>

                </select>
            </div>
        </div>
        <div class="row">
            <div class="col-sm-6" id="phone">
                <div class="form-group">
                    <label>Phone</label>
                    <?php echo Form::text('phone', old('phone', $setting->phone ? $setting->phone : ''), ['id' => '   ', 'class' => 'form-control', 'dir' => 'ltr']); ?>

                </div>
            </div>

            <div class="col-sm-6" id="twitter_link">
                <div class="form-group">
                    <label>Address</label>
                    <?php echo Form::textarea('address', old('address', $setting->address ? $setting->address : ''), ['id' => 'address', 'class' => 'form-control', 'dir' => 'ltr', 'rows' => 2]); ?>

                </div>
            </div>
        </div>

        
        <div class="row">
            <div class="col-sm-6" id="facebook_link">
                <div class="form-group">
                    <label>Facebook Link</label>
                    <?php echo Form::url('facebook_link', env('FACEBOOK_LINK'), ['id' => 'facebook_link', 'class' => 'form-control', 'dir' => 'ltr']); ?>

                </div>
            </div>
            <div class="col-sm-6" id="twitter_link">
                <div class="form-group">
                    <label>Twitter Link</label>
                    <?php echo Form::url('twitter_link', env('TWITTER_LINK'), ['id' => 'twitter_link', 'class' => 'form-control', 'dir' => 'ltr']); ?>

                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-sm-6" id="youtube_link">
                <div class="form-group">
                    <label>Youtube Link</label>
                    <?php echo Form::url('youtube_link', env('YOUTUBE_LINK'), ['id' => 'youtube_link', 'class' => 'form-control', 'dir' => 'ltr']); ?>

                </div>
            </div>
            <div class="col-sm-6" id="instagram_link">
                <div class="form-group">
                    <label>Instagram Link</label>
                    <?php echo Form::url('instagram_link', env('INSTAGRAM_LINK'), ['id' => 'instagram_link', 'class' => 'form-control', 'dir' => 'ltr']); ?>

                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-sm-6" id="copyright_en">
                <div class="form-group">
                    <label>Copy Right</label>
                    <?php echo Form::text('copyright_en', old('copyright_en', $WebmasterSetting->copyright_en ? $WebmasterSetting->copyright_en : ''), ['id' => 'copyright_en', 'class' => 'form-control', 'dir' => 'ltr']); ?>

                </div>
            </div>
            <div class="col-sm-6" id="site_title_en">
                <div class="form-group">
                    <label>Site Title</label>
                    <?php echo Form::text('site_title_en', old('site_title_en', @$WebmasterSetting->site_title_en ? $WebmasterSetting->site_title_en : ''), ['id' => 'site_title_en', 'class' => 'form-control', 'dir' => 'ltr']); ?>

                </div>
            </div>
        </div>
       

        
    </div>
</div>
<?php /**PATH /home/netcofin/public_html/resources/views/dashboard/webmaster/settings/language.blade.php ENDPATH**/ ?>