<?php $__env->startSection('title', __('backend.add_subscription_plan')); ?>
<?php $__env->startPush('after-styles'); ?>
    <link href="<?php echo e(asset('assets/dashboard/js/iconpicker/fontawesome-iconpicker.min.css')); ?>" rel="stylesheet">

    <link rel="stylesheet"
        href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.9.0/css/bootstrap-datepicker.min.css" />

    <!--[if lt IE 9]>
        <script src="//html5shim.googlecode.com/svn/trunk/html5.js"></script>
        <![endif]-->

    <style type="text/css">
        .error {
            color: red;
            margin-left: 5px;
        }

    </style>
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
    <div class="padding edit-package">
        <div class="box">
            <div class="box-header dker">
                <h3><i class="material-icons">
                        &#xe02e;</i> <?php echo e(__('backend.add_subscription_plan')); ?>

                </h3>
                <small>
                    <a href="<?php echo e(route('adminHome')); ?>"><?php echo e(__('backend.home')); ?></a> /
                    <a href="<?php echo e(route('subscription_plans')); ?>"><?php echo e(__('backend.subscription_plans')); ?></a> /
                    <span><?php echo e(__('backend.add_subscription_plan')); ?></span>
                </small>
            </div>

            <div class="box-body">
                <?php echo e(Form::open(['route' => ['subscription_plan.store'],'method' => 'POST','files' => true,'enctype' => 'multipart/form-data','id' => 'subscription_planForm'])); ?>


                <?php echo csrf_field(); ?>
                <div class="personal_informations">
                    <div class="form-group row">
                        <label class="col-sm-2 form-control-label"><?php echo __('backend.subscription_plan_name'); ?></label>
                        <div class="col-sm-10">
                            <input type="text" name="plan_name" id="plan_name" class="form-control"
                                placeholder="<?php echo e(__('backend.subscription_plan_name')); ?>" value="<?php echo e(old('plan_name')); ?>"
                                maxlength="100">

                            <span class="help-block">
                                <?php if(!empty(@$errors) && @$errors->has('plan_name')): ?>
                                    <span style="color: red;" class='validate'><?php echo e($errors->first('plan_name')); ?></span>
                                <?php endif; ?>
                            </span>
                        </div>
                    </div>

                    <div class="form-group row">
                        <label class="col-sm-2 form-control-label"><?php echo __('backend.subscription_plan_description'); ?></label>
                        <div class="col-sm-10">
                            <textarea name="plan_description" id="plan_description" class="form-control" rows="5" placeholder="<?php echo e(__('backend.subscription_plan_description')); ?>"><?php echo e(old('plan_description')); ?></textarea>

                            <span class="help-block">
                                <?php if(!empty(@$errors) && @$errors->has('plan_description')): ?>
                                    <span style="color: red;" class='validate'><?php echo e($errors->first('plan_description')); ?></span>
                                <?php endif; ?>
                            </span>
                        </div>
                    </div>

                    <div class="form-group row">
                        <label class="col-sm-2 form-control-label"><?php echo __('backend.subscription_plan_duration'); ?></label>
                        <div class="col-sm-7">
                            <input type="text" name="plan_duration_value" id="plan_duration_value" class="form-control"
                                placeholder="<?php echo e(__('backend.subscription_plan_duration')); ?>" value="<?php echo e(old('plan_duration_value')); ?>"
                                maxlength="4">

                            <span class="help-block">
                                <?php if(!empty(@$errors) && @$errors->has('plan_duration_value')): ?>
                                    <span style="color: red;" class='validate'><?php echo e($errors->first('plan_duration_value')); ?></span>
                                <?php endif; ?>
                            </span>
                        </div>
                        <div class="col-sm-3">
                            <select name="plan_duration_type" id="plan_duration_type" class="form-control" value="<?php echo e(old('plan_duration_type')); ?>">
                                <?php $__currentLoopData = config('constants.PLAN_DURATION_TYPE'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($key); ?>"><?php echo e(Helper::getLabelValueByKey($item['label_key'])); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        
                    </div>

                    <div class="form-group row">
                        <label class="col-sm-2 form-control-label"><?php echo __('backend.subscription_plan_price'); ?></label>
                        <div class="col-sm-10">
                            <input type="text" name="plan_price" id="plan_price" class="form-control decimal"
                                placeholder="<?php echo e(__('backend.subscription_plan_price')); ?>" value="<?php echo e(old('plan_price')); ?>"
                                maxlength="15">

                            <span class="help-block">
                                <?php if(!empty(@$errors) && @$errors->has('plan_price')): ?>
                                    <span style="color: red;" class='validate'><?php echo e($errors->first('plan_price')); ?></span>
                                <?php endif; ?>
                            </span>
                        </div>
                    </div>

                    <div class="form-group row">
                        <label class="col-sm-2 form-control-label"><?php echo __('backend.is_free_plan'); ?></label>
                        <div class="col-sm-10">
                            <?php echo Form::checkbox('is_free', 1, old('is_free')?true:false, ['class' => 'from-control-label','style'=> 'margin-top:15px;','id'=> 'is_free']); ?>

                        </div>
                    </div>


                </div>

                <div class="form-group row m-t-md">
                    <div class="offset-sm-2 col-sm-10">
                        <button type="submit" class="btn btn-primary m-t" id="submitDetail"><i
                                class="material-icons">&#xe31b;</i> <?php echo __('backend.add'); ?></button>
                        <a href="<?php echo e(route('subscription_plans')); ?>" class="btn btn-default m-t">
                            <i class="material-icons">
                                &#xe5cd;</i> <?php echo __('backend.cancel'); ?>

                        </a>
                    </div>
                </div>


                <?php echo e(Form::close()); ?>

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('after-scripts'); ?>
    <script src="<?php echo e(asset('assets/dashboard/js/iconpicker/fontawesome-iconpicker.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/dashboard/js/summernote/dist/summernote.js')); ?>"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.9.0/js/bootstrap-datepicker.min.js"></script>



    <script>
        $(function() {
            $('.icp-auto').iconpicker({
                placement: '<?php echo e(@Helper::currentLanguage()->direction == 'rtl' ? 'topLeft' : 'topRight'); ?>'
            });
        });

        // update progress bar
        function progressHandlingFunction(e) {
            if (e.lengthComputable) {
                $('progress').attr({
                    value: e.loaded,
                    max: e.total
                });
                // reset progress on complete
                if (e.loaded == e.total) {
                    $('progress').attr('value', '0.0');
                }
            }
        }
    </script>
    <script type="text/javascript">


    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('dashboard.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/netcofin/public_html/resources/views/dashboard/subscription_plans/create.blade.php ENDPATH**/ ?>